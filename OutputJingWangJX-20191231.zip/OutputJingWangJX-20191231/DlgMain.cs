﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Runtime.InteropServices;
using System.Collections.Specialized;
using System.Diagnostics;
using System.IO;

using Pub;
using Report;
using System.Threading;
using System.Runtime.CompilerServices;

//1.
//oew.ini outputCust=4
//oew.ini OutputGuard=3
//oew.ini OutputExec = OutputShengHongHDI.exe
//2.
//OEW.exe 4.8.11.2609
//3.
//D:\Output\Time.ini
//[Path]
//Data =
//Signal =
//Password =
//User =
//Picture =
//wat =
//upwat =

namespace Output
{

	public partial class DlgMain : Form
	{
		#region 加载预处理
		[DllImport("user32", EntryPoint = "SetWindowPos")]
		public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndlnsertAfter, int X, int Y, int cx, int cy, int flags);
		[DllImport("user32", EntryPoint = "IsWindowVisible")]
		public static extern bool IsWindowVisible(IntPtr hWnd);
		[DllImport("Kernel32.dll", SetLastError = true)]
		static extern IntPtr OpenEvent(uint dwDesiredAccess, bool bInheritHandle, string lpName);
		const uint STANDARD_RIGHTS_REQUIRED = 0x000F0000;
		const uint SYNCHRONIZE = 0x00100000;
		const uint EVENT_ALL_ACCESS = (STANDARD_RIGHTS_REQUIRED | SYNCHRONIZE | 0x3);
		const uint EVENT_MODIFY_STATE = 0x0002;
		const long ERROR_FILE_NOT_FOUND = 2L;

		[DllImport("kernel32.dll")]
		static extern bool SetEvent(IntPtr hEvent);

		string lang;
		string dataPath;
		// AOI主机名称与类型字典
		public Dictionary<string, int> servers = new Dictionary<string, int>();
		// 每AOI主机类型的缺点类型字典
		//                主机类型ID
		//                     缺点类型ID与名称字典（OEW中使用的类型ID）
		public Dictionary<int, StringDictionary> srvcls = new Dictionary<int, StringDictionary>();

		IniFiles outIni = null;
		IniFiles signalIni = null;
		public string outPath;                      // Output起始路径
		DateTime[] lotSumTime = new DateTime[2];    // Lot汇总数据生成时间

		static string lotSumPath;      // Lot汇总数据输出路径
		static string alarmPath;       // Alarm数据输出路径
		static string signalPath;      // 实时状态输出路径
		int alarmThreshold;     // Alarm数据上传阀值

		List<Signal> signals = new List<Signal>();
		// 界面手动触发的信号
		Signal[] manualSignals = new Signal[3];

		/// <summary>
		/// 惠州胜宏
		/// </summary>
		public static ShengHong sheng = new ShengHong();
		/// <summary>
		/// 待料时间
		/// </summary>
		public static System.Timers.Timer t_wat = new System.Timers.Timer(600000);   //实例化Timer类，设置间隔时间为600000毫秒；   
		/// <summary>
		/// 上传时间
		/// </summary>
		public static System.Timers.Timer timershare = new System.Timers.Timer();   //实例化Timer类，设置间隔时间为10000毫秒；  

		Log log = null;

		bool IsNoChanged(int side)
		{
			DateTime noTime = new DateTime();
			return (DateTime.TryParse(
					outIni.ReadString("Verify" + side.ToString(), "NoTime", ""),
					out noTime) &&
				noTime > lotSumTime[side]);
		}

		public DlgMain()
		{
			InitializeComponent();
		}

		private void Main_Load(object sender, EventArgs e)
		{
            buttonLoad_Click(null, null);
            UploadData();
        }

		private void buttonLoad_Click(object sender, EventArgs e)
		{
			lblVersion2.Text = System.Windows.Forms.Application.ProductVersion;

			IniFiles oewIni = new IniFiles("oew.ini");
			// 读取AOI名称与类型ID的对照表
			StringCollection sc = new StringCollection();
			oewIni.ReadSections(sc);
			foreach (string s in sc)
				if (string.Compare(s, 0, "AOI", 0, 3) == 0)
					servers[oewIni.ReadString(s, "Name", "")] = oewIni.ReadInteger(s, "Type", 0);
			servers.Remove("");
			if (servers.Count == 0)
				MessageBox.Show("请先建立AOI列表。");

			// 读取语言设定
			IniFiles sr = new IniFiles("Resources\\sr.ini");
			string defLang = sr.ReadString("Lang", "defaultLang", "");
			lang = sr.ReadString("Lang", "lang", defLang);
			dataPath = oewIni.ReadString("Coordinate", "ClassSavePath", "D:\\Report\\");

			// 读取各AOI的缺点类型
			IniFiles dc = new IniFiles("Resources\\dc_" + lang + ".ini");
			char[] split = new char[] { ',' };
			for (int i = 0; i < 100; i++)
			{
				StringDictionary srv = new StringDictionary();
				string section = "AT" + i.ToString();
				string keys = dc.ReadString(section, "Keys", "");
				string[] ks = keys.Split(split, StringSplitOptions.RemoveEmptyEntries);
				foreach (string s in ks)
					srv[s] = dc.ReadString(section, "n" + s, "");
				srvcls[i] = srv;
			}

			outPath = oewIni.ReadPath("General", "OutputPath", @"D:\Output\");
			Directory.CreateDirectory(outPath + @"\Lot");

			outIni = new IniFiles(outPath + "Output.ini");
			if (outIni.ReadBool("General", "RunManual", false) == false)
			{
				// 不允许手动启动程序
				DateTime now = DateTime.Now;
				string pid = Process.GetCurrentProcess().Id.ToString();
				string wait = "waiting";
				while (wait == "waiting")
				{
					wait = outIni.ReadString("General", "OutID", "");
					if (wait == pid)
						break;  // 由OEW启动，则继续运行
					if (wait == "waiting")
					{
						if ((DateTime.Now - now).TotalMilliseconds > 3000)
						{
							outIni.WriteString("General", "OutID", "");
							outIni.WriteString("General", "CallID", "");
							MessageBox.Show("等待超时，请重新启动主程序");
							Close();
							return;
						}
						else
							continue;
					}
					if (wait != pid)
					{
						MessageBox.Show("请设置随主程序一起启动，不允许手动运行。");
						Close();
						return;
					}
				}
			}
			Common.splits = outIni.ReadString("Common", "Split", Common.splits);
			if (Common.splits.Length == 0)
				Common.splits = "\t";
			Common.splitc = Common.splits[0];
			Common.dtFmt1 = outIni.ReadString("Common", "DateTimeFormat1", Common.dtFmt1);
			Common.dtFmt2 = outIni.ReadString("Common", "DateTimeFormat2", Common.dtFmt2);
			Common.eCust = Common.GetEncoding(outIni.ReadString("Common", "EncodingCustomer", Common.eCust.WebName));
			Common.fieldTitle = outIni.ReadBOOL("Common", "FieldTitle", Common.fieldTitle);
			Common.detailSum = outIni.ReadBOOL("Common", "DetailSum", Common.detailSum);
			for (int i = 0; i < 2; i++)
			{
				DateTime.TryParse(
					outIni.ReadString("Verify" + i.ToString(), "LotSumTime", ""),
					out lotSumTime[i]);
			}

			// 日志
			log = new Log(outIni, outPath, "Log");

			//路径默认路径，重启后会恢复默认
			lotSumPath = outIni.ReadPath("Path", "LotSumPath", @"D:\PC_EAP\DEVICE_AOIJXZ\PC_DATA");
			alarmPath = outIni.ReadPath("Path", "AlarmPath", @"D:\PC_EAP\DEVICE_AOIJXZ\PC_SIGNAL");
			signalPath = outIni.ReadPath("Path", "SignalPath", @"D:\PC_EAP\DEVICE_AOIJXZ\PC_SIGNAL");
			alarmThreshold = outIni.ReadInteger("Threshold", "Alarm", 1);

			for (int i = 0; i < 3; i++)
				((CheckBox)gbAlarm.Controls[i]).Checked = outIni.ReadBool("Alarm", i.ToString(), false);

			// 监视实时信号文件
			signalIni = new IniFiles(outPath + "Signal.ini");
			Signal signal = null;
			// EmergencyStop
			signal = new Signal();
			signal.key = "EmergencyStop";
			signal.name = "EmergencyStop";
			signal.text = "紧急停止";
			signal.value = signalIni.ReadInteger("Signal", signal.key, 0);
			signals.Add(signal);
			// Power
			signal = new Signal();
			signal.key = "Startup";
			signal.name = "Power";
			signal.text = "设备上机/停机";
			signal.value = signalIni.ReadInteger("Signal", signal.key, 0);
			signals.Add(signal);
			// Product
			signal = new Signal();
			signal.key = "Working";
			signal.name = "Product";
			signal.text = "生产开始/结束";
			signal.value = signalIni.ReadInteger("Signal", signal.key, 0);
			signals.Add(signal);
			// WaitMaterial
			manualSignals[0] = signal = new Signal();
			signal.key = "WaitMaterial";
			signal.name = "WaitMaterial";
			signal.text = "设备待料";
			signal.value = signalIni.ReadInteger("Signal", signal.key, 0);
			signals.Add(signal);
			cbSignal1.Checked = signal.value != 0;  // 界面手动产生，设置初始状态
													// TotalAlarm
			manualSignals[1] = signal = new Signal();
			signal.key = "TotalAlarm";
			signal.name = "TotalAlarm";
			signal.text = "设备总故障状态";
			signal.value = signalIni.ReadInteger("Signal", signal.key, 0);
			signals.Add(signal);
			cbSignal2.Checked = signal.value != 0;
			// StopLine
			manualSignals[2] = signal = new Signal();
			signal.key = "StopLine";
			signal.name = "StopLine";
			signal.text = "设备重大故障(停线故障)";
			signal.value = signalIni.ReadInteger("Signal", signal.key, 0);
			signals.Add(signal);
			cbSignal3.Checked = signal.value != 0;

			fswSignal.Path = outPath;
			fswSignal.EnableRaisingEvents = true;

			fswData.Path = outPath + "Data";
			fswData.EnableRaisingEvents = true;

			// 通知主程序启动完成
			IntPtr ip = OpenEvent(EVENT_ALL_ACCESS, false, "OutputInited");
			if (ip != IntPtr.Zero)
				SetEvent(ip);

			buttonLoad.Visible = false;
			// 待料时间
			sheng.Setting(outPath, oewIni);
			if (sheng.Wat != 0 && t_wat.Interval != sheng.Wat)
				t_wat.Interval = sheng.Wat;
			t_wat.Elapsed += new System.Timers.ElapsedEventHandler(theout); //到达时间的时候执行事件；   
			t_wat.AutoReset = true;   //设置是执行一次（false）还是一直执行(true)；   
			t_wat.Enabled = false;     //是否执行System.Timers.Timer.Elapsed事件；
			timerStart.Start();
			UploadData();
			//上传时间
			if (sheng.upwat != 0 && timershare.Interval != sheng.upwat)
				timershare.Interval = sheng.upwat;
			timershare.Elapsed += new System.Timers.ElapsedEventHandler(theshare); //到达时间的时候执行事件；   
			timershare.AutoReset = true;   //设置是执行一次（false）还是一直执行(true)；   
			timershare.Enabled = true;     //是否执行System.Timers.Timer.Elapsed事件；
            timershare.Start();
        }

		#endregion

        #region 没有更改

        #region 相机异常，运动异常，连接异常，即设备报警与复位数据采集

        void SaveAlarmState(int index, bool alarmed)
		{
			outIni.WriteBool("Alarm", index.ToString(), alarmed);

			string[] fields = new string[5];
			fields[0] = "";         // 唯一ID，非必须
			fields[1] = "VRS_ALARM_" + (index + 1).ToString();  // 报警代码
			fields[2] = "";         // 报警描述
			switch (index)
			{
				case 0:
					fields[2] = "连接异常";
					break;
				case 1:
					fields[2] = "运动异常";
					break;
				case 2:
					fields[2] = "相机异常";
					break;
			}
			fields[3] = alarmed ? "1" : "0";
			fields[4] = DateTime.Now.ToString(Common.dtFmt1);

			string file = "ALARMDATA";
			string ext = ".csv";
			string fullname = outPath + file + ext;
			bool exist = File.Exists(fullname);
			using (StreamWriter sw = new StreamWriter(fullname, true, Common.eCust))
			{
				if (exist == false && Common.fieldTitle)
				{
					string[] titles = new string[5];
					titles[0] = "ID";
					titles[1] = "ALARMCODE";
					titles[2] = "ALARMDES";
					titles[3] = "ALARMVALUE";
					titles[4] = "CREATETIME";
					string titleline = Common.GetLine(titles);
					sw.WriteLine(titleline);
				}
				int id = exist ? outIni.ReadInteger("Id", "Alarm", 1) : 1;
				fields[0] = id.ToString();
				string line = Common.GetLine(fields);
				sw.WriteLine(line);
				outIni.WriteInteger("Id", "Alarm", id + 1);
			}
			// 重新创建文件的创建时间需要更新，否则可能还是之前删除同名文件的时间
			if (exist == false)
				File.SetCreationTime(fullname, DateTime.Now);
			MoveThresholdFile(file, ext, alarmPath);
		}

		void MoveThresholdFile(string file, string ext, string destPath)
		{
			// 文本行数超过阀值则移动至输出目录
			int count = outIni.ReadInteger("Id", "Alarm", 0);
			if (count > alarmThreshold)
			{
				Directory.CreateDirectory(destPath);
				string fullname = outPath + file + ext;
				var r = new FileInfo(fullname);
				File.Move(r.FullName, destPath + r.Name);
			}
		}

		private void cbAlarm_Click(object sender, EventArgs e)
		{
			CheckBox cb = (CheckBox)sender;
			int i = gbAlarm.Controls.GetChildIndex(cb, false);
			if (i >= 0)
				SaveAlarmState(i, cb.Checked);
		}

		private void cbAlarm_CheckedChanged(object sender, EventArgs e)
		{
			// 更新图标灯颜色
			CheckBox cb = (CheckBox)sender;
			if (cb.Enabled)
				cb.ImageIndex = cb.Checked ? 2 : 1;
			else
				cb.ImageIndex = 0;
			// 如果有报警，窗口置于最顶层
			//bool top = false;
			//foreach (Control c in gbAlarm.Controls)
			//    top |= ((CheckBox)c).Checked;
			//if (TopMost != top)
			//    TopMost = top;
		}
		#endregion

		#region 关闭按钮事件
		private void Main_FormClosing(object sender, FormClosingEventArgs e)
		{
			if (int.TryParse(outIni.ReadString("General", "CallID", ""), out int callID))
			{
				try
				{
					Process p = Process.GetProcessById(callID);
					if (p.HasExited == false)
					{
						MessageBox.Show("请先关闭主程序。");
						e.Cancel = true;
					}
				}
				catch { }
			}
			sheng.timeiniWrite(key: "");
		}
		#endregion

		#region 设置按钮单击事件
		private void btnSettings_Click(object sender, EventArgs e)
		{
			bool topMost = TopMost;
			TopMost = false;

			DlgSettings dlg = new DlgSettings();
			dlg.tbLotSumPath.Text = lotSumPath;
			dlg.tbAlarmPath.Text = alarmPath;
			dlg.tbSignalPath.Text = signalPath;
			dlg.tbAlarm.Text = alarmThreshold.ToString();

			if (dlg.ShowDialog() == DialogResult.OK)
			{
				if (lotSumPath != dlg.tbLotSumPath.Text)
				{
					lotSumPath = dlg.tbLotSumPath.Text;
					outIni.WriteString("Path", "LotSumPath", lotSumPath);
				}
				if (alarmPath != dlg.tbAlarmPath.Text)
				{
					alarmPath = dlg.tbAlarmPath.Text;
					outIni.WriteString("Path", "AlarmPath", alarmPath);
				}
				if (signalPath != dlg.tbSignalPath.Text)
				{
					signalPath = dlg.tbSignalPath.Text;
					outIni.WriteString("Path", "RealStatePath", signalPath);
				}
				int value;
				if (int.TryParse(dlg.tbAlarm.Text, out value) && alarmThreshold != value)
				{
					alarmThreshold = value;
					outIni.WriteInteger("Threshold", "Alarm", alarmThreshold);
				}
			}

			TopMost = topMost;
		}
		#endregion
		#endregion

		#region 设备待料，总故障 ，线故障,即设备实时信号
		private void fswSignal_Changed(object sender, FileSystemEventArgs e)
		{
			foreach (Signal signal in signals)
			{
				int v = signalIni.ReadInteger("Signal", signal.key, 0);
				if (signal.value != v)
				{
					signal.value = v;
					//把signal传递OutputSignal，OutputSignal输出.csv文件
					OutputSignal(signal);
				}
			}
		}

		public void theout(object source, System.Timers.ElapsedEventArgs e)
		{
			theout_t(1);
			if (sheng.Wat != 0 && t_wat.Interval != sheng.Wat)
				t_wat.Interval = sheng.Wat;
		}

		public void theout_t(int I)
		{

			if (I == 1)
			{
				t_wat.Enabled = false;
				t_wat.Stop();
			}
			Signal signal = new Signal();
			signal.key = "WaitMaterial";
			signal.name = "WaitMaterial";
			signal.text = "设备待料";
			signal.value = (I == 1) ? 1 : 0;
			sheng.showFaulttime(signal);
            DateTime now = DateTime.Now;
            string[] fields = new string[4];
            fields[0] = signal.name.ToUpper();  // 信号代码
            fields[1] = signal.text;            // 信号描述
            fields[2] = signal.value.ToString();// 信号值
            fields[3] = now.ToString(Common.dtFmt1);
            string line = Common.GetLine(fields);
            string file = fields[0] + "_" + now.ToString(Common.dtFmt2);
            string ext = ".csv";
            string fullname = outPath + file + ext;
            using (StreamWriter sw = new StreamWriter(fullname, true, Common.eCust))
            {
                if (Common.fieldTitle)
                {
                    string[] titles = new string[4];
                    titles[0] = "SIGNALCODE";
                    titles[1] = "SIGNALDES";
                    titles[2] = "SIGNALVALUE";
                    titles[3] = "CREATETIME";
                    string titleline = Common.GetLine(titles);
                    sw.WriteLine(titleline);
                }
                sw.WriteLine(line);
            }
            Directory.CreateDirectory(signalPath);
            var r = new FileInfo(fullname);
            File.Move(r.FullName, signalPath + r.Name);
        }

		private void OutputSignal(Signal signal)
		{
			bool? b_t = sheng.WAT_TIMER;
			if (b_t == true && t_wat.Enabled == true)
			{
				t_wat.Enabled = false;
				t_wat.Stop();
				sheng.WAT_TIMER = false;
			}
			else if (b_t == true && t_wat.Enabled == false)
			{
				theout_t(0);
				sheng.WAT_TIMER = false;
			}
			sheng.showFaulttime(signal);
			signalIni.WriteInteger("Signal", signal.key, signal.value);
			DateTime now = DateTime.Now;
			string[] fields = new string[4];
			fields[0] = signal.name.ToUpper();  // 信号代码
			fields[1] = signal.text;            // 信号描述
			fields[2] = signal.value.ToString();// 信号值
			fields[3] = now.ToString(Common.dtFmt1);
			string line = Common.GetLine(fields);
			string file = fields[0] + "_" + now.ToString(Common.dtFmt2);
			string ext = ".csv";
			string fullname = outPath + file + ext;
			using (StreamWriter sw = new StreamWriter(fullname, true, Common.eCust))
			{
				if (Common.fieldTitle)
				{
					string[] titles = new string[4];
					titles[0] = "SIGNALCODE";
					titles[1] = "SIGNALDES";
					titles[2] = "SIGNALVALUE";
					titles[3] = "CREATETIME";
					string titleline = Common.GetLine(titles);
					sw.WriteLine(titleline);
				}
				sw.WriteLine(line);
			}
			Directory.CreateDirectory(signalPath);
			var r = new FileInfo(fullname);
			File.Move(r.FullName, signalPath + r.Name);
			//开机，生产结束，故障之后要等待对应时间才输出待料
			if (sheng.WAT_TIMER == true)
			{
				t_wat.Enabled = true;
				t_wat.Start();
			}
		}

		#region 没有更改
		private void cbSignal_Click(object sender, EventArgs e)
		{
			CheckBox cb = (CheckBox)sender;
			// 注意控件顺序在Designer.cs文件中为反序，需要调整
			int i = gbSignal.Controls.GetChildIndex(cb, false);
			//signalIni.WriteBOOL，根据界面手动触发的信号更改signal.ini文件"Signal对应manualSignals[i].key的值，cb.Checked为true改1，false改0
			if (i >= 0)
				signalIni.WriteBOOL("Signal", manualSignals[i].key, cb.Checked);
		}

		private void cbSignal_CheckedChanged(object sender, EventArgs e)
		{
			// 更新图标灯颜色
			CheckBox cb = (CheckBox)sender;
			if (cb.Enabled)
				cb.ImageIndex = cb.Checked ? 2 : 1;
			else
				cb.ImageIndex = 0;

			// 如果有报警，窗口置于最顶层
			//bool top = false;
			//foreach(Control c in gbSignal.Controls)
			//	top |= ((CheckBox)c).Checked;
			//if(TopMost != top)
			//	TopMost = top;
		}
		#endregion
		#endregion

		#region 定时上传文件
		public static async void method() => await Task.Run(new Action(S_save));

		private static void S_save()
		{
			timershare.Stop();
			timershare.Enabled = false;
			SharePath.connectState(ref sheng);
			if (sheng.sharePath.data_Linking || sheng.sharePath.signal_Linking)
				SharePath.Save(sheng.sharePath, lotSumPath, signalPath);
            if (sheng.upwat != 0 && timershare.Interval != sheng.upwat)
                timershare.Interval = sheng.upwat;
			timershare.Enabled = true;
			timershare.Start();
		}

		public void theshare(object source, System.Timers.ElapsedEventArgs e)
		{
			method();
		}

		#endregion

		#region  单件追溯
		private void fswData_Created(object sender, FileSystemEventArgs e)
		{
			UploadData();
		}

		private void UploadData()
		{
			if (Directory.Exists(System.IO.Path.Combine(outPath, "Data")))
			{
				foreach (var ini in Directory.EnumerateFiles(outPath + @"Data\", "*.txt"))
				{
					try
					{
						TimeSpan ts = DateTime.Now - Directory.GetLastWriteTime(ini);
						if (ts.Days > 31)
							File.Delete(ini);
					}
					catch (Exception ex) { }
				}
				foreach (string a in Directory.EnumerateFiles(outPath + @"Data\", "*.txt"))
				{
					//*_.txtz先改名，A_error得到错误路径
					string A = System.IO.Path.Combine(System.IO.Path.Combine(outPath, "Data"), System.IO.Path.GetFileNameWithoutExtension(a)) + "_" + File.GetCreationTime(a).ToString(Common.dtFmt2) + System.IO.Path.GetExtension(a);
					File.Move(a, A);
					string A_error = System.IO.Path.Combine(System.IO.Path.Combine(outPath, "Error"), System.IO.Path.GetFileNameWithoutExtension(A)) + System.IO.Path.GetExtension(A);
					if (!Directory.Exists(System.IO.Path.Combine(outPath, "Error")))
						Directory.CreateDirectory(System.IO.Path.Combine(outPath, "Error"));
					var V = new FileInfo(a);
					var str_name = V.Name.Substring(0, V.Name.LastIndexOf("."));
					var str_csv = "";
					//如果报错把文件转移
					try
					{
						using (StreamReader sr = new StreamReader(A))
						{
							Dictionary<string, string> ds = new Dictionary<string, string>();
							foreach (string s in sr.ReadToEnd().Split(new String[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries))
							{
								string[] fields = s.Split(new char[] { '=' }, StringSplitOptions.None);
								if (fields.GetUpperBound(0) == 1)
									ds[fields[0]] = fields[1];
							}
							sr.Close();
							Txtclass txtclass = new Txtclass()
							{
								VRS_NO = ds["VRS"],
								AOI_NO = ds["AOI"],
								FLOW_NO = "",
								PART_NO = ds["料号"],
								LOT_NO = ds["批号"],
								PNL_NO = "",
								Xuhao_NO = ds["序号"],
								Layers = ds["层别"],
								Set = ds["SET数"],
								G_Set = ds["良品SET数"],
								F_Set = (Convert.ToInt32(ds["SET数"]) - Convert.ToInt32(ds["良品SET数"])).ToString(),
								Pcs = ds["PCS数"],
								G_Pcs = ds["良品PCS数"],
								F_Pcs = (Convert.ToInt32(ds["PCS数"]) - Convert.ToInt32(ds["良品PCS数"])).ToString(),
								START_DATE = ds["操作开始时间"],
								END_DATE = ds["操作结束时间"],
								RECORD_DATE = DateTime.Now.ToString(),
								USER = ds["操作员"]
							};
							var sum = ds.Where(d => d.Key.Contains("D_") && d.Value != 0.ToString()).ToList();
							if (sum.Count <= 0)
							{
								sum = ds.Where(d => d.Key.Contains("不良点数")).ToList();
							}
							if (sum.Count > 0)
							{
								string dstFile = outPath + "SINGLETRACEDATA_" + str_name + "_" + DateTime.Now.ToString(Common.dtFmt2);
								string ext = ".csv";
								string fullname = dstFile + ext;
								str_csv = fullname;
								using (StreamWriter sw = new StreamWriter(fullname, true, Common.eCust))
								{
									if (Common.fieldTitle)
									{
										string[] titles = new string[20];

										titles[0] = "VRS_NO";
										titles[1] = "AOI_NO";										
										titles[2] = "PART_NO";
										titles[3] = "LOT_NO";
										titles[4] = "Layers";
										titles[5] = "Xuhao_NO";

										titles[6] = "FLOW_NO";
										titles[7] = "PNL_NO";

										titles[8] = "Set";
										titles[9] = "G_Set";
										titles[10] = "F_Set";
										titles[11] = "Pcs";
										titles[12] = "G_Pcs";
										titles[13] = "F_Pcs";
										titles[14] = "START_DATE";
										titles[15] = "END_DATE";
										titles[16] = "RECORD_DATE";
										titles[17] = "USER";

										titles[18] = "ITEMCODE";
										titles[19] = "ITEMVALUE";
										string titleline = Common.GetLine(titles);
										sw.WriteLine(titleline);
									}
									foreach (var v in sum)
									{
										string[] Fields = new string[20];
										Fields[0] = txtclass.VRS_NO;
										Fields[1] = txtclass.AOI_NO;
										Fields[2] = txtclass.PART_NO;
										Fields[3] = txtclass.LOT_NO;
										Fields[4] = txtclass.Layers;
										Fields[5] = txtclass.Xuhao_NO;
										
										Fields[6] = txtclass.FLOW_NO;
										Fields[7] = txtclass.PNL_NO;
										
										Fields[8] = txtclass.Set;
										Fields[9] = txtclass.G_Set;
										Fields[10] = txtclass.F_Set;
										Fields[11] = txtclass.Pcs;
										Fields[12] = txtclass.G_Pcs;
										Fields[13] = txtclass.F_Pcs;
										Fields[14] = txtclass.START_DATE;
										Fields[15] = txtclass.END_DATE;
										Fields[16] = txtclass.RECORD_DATE;
										Fields[17] = txtclass.USER;

										Fields[18] = v.Key.Replace("D_", "");
										Fields[19] = v.Value.ToString();
										sw.WriteLine(Common.GetLine(Fields));
									}
								}
								Directory.CreateDirectory(lotSumPath);
								var r = new FileInfo(fullname);
								File.Move(r.FullName, lotSumPath + r.Name);
                            }
						}
					}
					catch (Exception ex)
					{
						log.Write(ex, a);
						if (!File.Exists(A_error))
							File.Move(A, A_error);
					}
					if (File.Exists(A))
						File.Delete(A);
					if (!string.IsNullOrEmpty(str_csv) || File.Exists(str_csv))
						File.Delete(str_csv);
				}
			}
		}

		//private void UpdateError()
		//{
		//	//if (Directory.Exists(System.IO.Path.Combine(outPath, "Error")))
		//	//{
		//	//	var dir = new DirectoryInfo(System.IO.Path.Combine(outPath, "Error"));
		//	//	var inf = dir.GetFiles();
		//	//	List<string> FileList = new List<string>();
		//	//	foreach (var a in inf.Where(f => f.FullName.Contains(".txt")).OrderByDescending(f => f.FullName))
		//	//	{
		//	//		FileList.Add(a.FullName.ToString());
		//	//	}
		//	//	foreach (var a in FileList)
		//	//	{
		//	//		try
		//	//		{
		//	//			using (StreamReader sra = new StreamReader(a))
		//	//			{
		//	//				Dictionary<string, string> dsa = new Dictionary<string, string>();
		//	//				foreach (string s in sra.ReadToEnd().Split(new String[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries))
		//	//				{
		//	//					string[] fields = s.Split(new char[] { '=' }, StringSplitOptions.None);
		//	//					if (fields.GetUpperBound(0) == 1)
		//	//						dsa[fields[0]] = fields[1];
		//	//				}
		//	//				sra.Close();
		//	//				List<string> line = new List<string>();
		//	//				foreach (var v in dsa)
		//	//				{
		//	//					string[] Fields = new string[2];
		//	//					Fields[0] = v.Key;
		//	//					Fields[1] = v.Value;
		//	//					line.Add(Common.GetLine(Fields));
		//	//				}
		//	//				string dstFile = outPath + "SINGLETRACEDATA_" + DateTime.Now.ToString(Common.dtFmt2);
		//	//				string ext = ".csv";
		//	//				string fullname = outPath + dstFile + ext;
		//	//				using (StreamWriter sw = new StreamWriter(fullname, true, Common.eCust))
		//	//				{
		//	//					if (Common.fieldTitle)
		//	//					{
		//	//						string[] titles = new string[2];
		//	//						titles[0] = "ITEMCODE";
		//	//						titles[1] = "ITEMVALUE";
		//	//						string titleline = Common.GetLine(titles);
		//	//						sw.WriteLine(titleline);
		//	//					}
		//	//					sw.WriteLine(line);
		//	//				}
		//	//				Directory.CreateDirectory(signalPath);
		//	//				string destFullname = signalPath + dstFile + ext;
		//	//				sheng.sharePath.Save(sheng.sharePath, new FileInfo(fullname), "Data", signalPath);
		//	//			}
		//	//			if (File.Exists(a))
		//	//				File.Delete(a);
		//	//		}
		//	//		catch (Exception ex)
		//	//		{
		//	//			log.Write(ex, a);
		//	//		}
		//	//	}
		//	//}
		//	//else
		//	//{
		//	//	Directory.CreateDirectory(System.IO.Path.Combine(outPath, "Error"));
		//	//}
		//}
		#endregion

		#region 报警统计文件
		private void timerStart_Tick(object sender, EventArgs e)
        {
			if (
				DateTime.Now.ToShortTimeString().Equals(sheng.Tshift.starttime.ToShortTimeString()) || DateTime.Now.ToShortTimeString().Equals(sheng.Tshift.endtime.ToShortTimeString())
				&& DateTime.Now.Second == 0
				)
			{
				timerStart.Enabled =true;
				buttonUpload_Click(null, null);
				timerStart.Enabled = false;
			}
		}
        
        private void buttonUpload_Click(object sender, EventArgs e)
        {
			sheng.Output(lotSumPath);
		}

		private void buttonUpload_MouseHover(object sender, EventArgs e)
		{
			System.Windows.Forms.ToolTip ToolTip1 = new System.Windows.Forms.ToolTip();
			ToolTip1.SetToolTip(this.buttonUpload, "统计报警文件并上传");
		}
        #endregion
    }

    #region 通用类(对象)
    public class Signal
	{
		public string key;		// 内部关键字
		public string name;		// 客户使用的关键字
		public string text;		// 客户使用的描述
		public int value;
	}

	public class Common
	{
		public static string splits = "\t";
		public static char splitc = splits[0];
		public static string dtFmt1 = "yyyy-MM-dd HH:mm:ss";	// 字段中的日期格式
		public static string dtFmt2 = "yyyyMMddHHmmssfff";	// 文件名中的日期格式
		public static Encoding eCust = Encoding.Unicode;	// 客户文本文件编码
		public static bool fieldTitle = true;				// 是否输出字段名称
		public static bool detailSum = false;				// 是否输出详细统计数据

		public static Encoding GetEncoding(string s)
		{
			Encoding e;
			try{
				int id;
				e = int.TryParse(s, out id) ?
					Encoding.GetEncoding(id) : Encoding.GetEncoding(s);
			}
			catch(Exception ex)
			{
				MessageBox.Show("语言代码设定有误，使用系统默认代码页。" + Environment.NewLine + ex.Message, "错误");
				e = Encoding.GetEncoding(0);
			}
			return e;
		}

		public static string GetLine(string[] fields)
		{
			string line = "";
			int ub = fields.GetUpperBound(0);
			for(int i = 0; i <= ub; i++)
				line += (i == 0 ? "" : Common.splits) + fields[i];
			return line;
		}
	}
    #endregion
}
