﻿namespace Output
{
	partial class DlgSettings
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lbLotSumPath = new System.Windows.Forms.Label();
			this.tbLotSumPath = new System.Windows.Forms.TextBox();
			this.btLotSumPath = new System.Windows.Forms.Button();
			this.fbDlg1 = new System.Windows.Forms.FolderBrowserDialog();
			this.btnOk = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.lbAlarm = new System.Windows.Forms.Label();
			this.tbAlarm = new System.Windows.Forms.TextBox();
			this.btAlarmPath = new System.Windows.Forms.Button();
			this.tbAlarmPath = new System.Windows.Forms.TextBox();
			this.lbAlarmPath = new System.Windows.Forms.Label();
			this.btSignalPath = new System.Windows.Forms.Button();
			this.tbSignalPath = new System.Windows.Forms.TextBox();
			this.lbSignalPath = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// lbLotSumPath
			// 
			this.lbLotSumPath.AutoSize = true;
			this.lbLotSumPath.Location = new System.Drawing.Point(12, 9);
			this.lbLotSumPath.Name = "lbLotSumPath";
			this.lbLotSumPath.Size = new System.Drawing.Size(154, 14);
			this.lbLotSumPath.TabIndex = 0;
			this.lbLotSumPath.Text = "Lot汇总数据输出路径：";
			// 
			// tbLotSumPath
			// 
			this.tbLotSumPath.AllowDrop = true;
			this.tbLotSumPath.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			this.tbLotSumPath.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystemDirectories;
			this.tbLotSumPath.Location = new System.Drawing.Point(15, 26);
			this.tbLotSumPath.Name = "tbLotSumPath";
			this.tbLotSumPath.Size = new System.Drawing.Size(394, 23);
			this.tbLotSumPath.TabIndex = 1;
			// 
			// btLotSumPath
			// 
			this.btLotSumPath.Location = new System.Drawing.Point(415, 26);
			this.btLotSumPath.Name = "btLotSumPath";
			this.btLotSumPath.Size = new System.Drawing.Size(75, 23);
			this.btLotSumPath.TabIndex = 2;
			this.btLotSumPath.Text = "浏览...";
			this.btLotSumPath.UseVisualStyleBackColor = true;
			this.btLotSumPath.Click += new System.EventHandler(this.btPath_Click);
			// 
			// fbDlg1
			// 
			this.fbDlg1.RootFolder = System.Environment.SpecialFolder.MyComputer;
			// 
			// btnOk
			// 
			this.btnOk.Location = new System.Drawing.Point(334, 281);
			this.btnOk.Name = "btnOk";
			this.btnOk.Size = new System.Drawing.Size(75, 23);
			this.btnOk.TabIndex = 3;
			this.btnOk.Text = "确定";
			this.btnOk.UseVisualStyleBackColor = true;
			this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
			// 
			// btnCancel
			// 
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.Location = new System.Drawing.Point(415, 281);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(75, 23);
			this.btnCancel.TabIndex = 4;
			this.btnCancel.Text = "取消";
			this.btnCancel.UseVisualStyleBackColor = true;
			// 
			// lbAlarm
			// 
			this.lbAlarm.AutoSize = true;
			this.lbAlarm.Location = new System.Drawing.Point(12, 214);
			this.lbAlarm.Name = "lbAlarm";
			this.lbAlarm.Size = new System.Drawing.Size(105, 14);
			this.lbAlarm.TabIndex = 5;
			this.lbAlarm.Text = "报警上报数量：";
			// 
			// tbAlarm
			// 
			this.tbAlarm.Location = new System.Drawing.Point(15, 231);
			this.tbAlarm.Name = "tbAlarm";
			this.tbAlarm.Size = new System.Drawing.Size(102, 23);
			this.tbAlarm.TabIndex = 6;
			// 
			// btAlarmPath
			// 
			this.btAlarmPath.Location = new System.Drawing.Point(415, 69);
			this.btAlarmPath.Name = "btAlarmPath";
			this.btAlarmPath.Size = new System.Drawing.Size(75, 23);
			this.btAlarmPath.TabIndex = 9;
			this.btAlarmPath.Text = "浏览...";
			this.btAlarmPath.UseVisualStyleBackColor = true;
			this.btAlarmPath.Click += new System.EventHandler(this.btPath_Click);
			// 
			// tbAlarmPath
			// 
			this.tbAlarmPath.AllowDrop = true;
			this.tbAlarmPath.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			this.tbAlarmPath.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystemDirectories;
			this.tbAlarmPath.Location = new System.Drawing.Point(15, 69);
			this.tbAlarmPath.Name = "tbAlarmPath";
			this.tbAlarmPath.Size = new System.Drawing.Size(394, 23);
			this.tbAlarmPath.TabIndex = 8;
			// 
			// lbAlarmPath
			// 
			this.lbAlarmPath.AutoSize = true;
			this.lbAlarmPath.Location = new System.Drawing.Point(12, 52);
			this.lbAlarmPath.Name = "lbAlarmPath";
			this.lbAlarmPath.Size = new System.Drawing.Size(133, 14);
			this.lbAlarmPath.TabIndex = 7;
			this.lbAlarmPath.Text = "报警数据输出路径：";
			// 
			// btSignalPath
			// 
			this.btSignalPath.Location = new System.Drawing.Point(415, 112);
			this.btSignalPath.Name = "btSignalPath";
			this.btSignalPath.Size = new System.Drawing.Size(75, 23);
			this.btSignalPath.TabIndex = 12;
			this.btSignalPath.Text = "浏览...";
			this.btSignalPath.UseVisualStyleBackColor = true;
			this.btSignalPath.Click += new System.EventHandler(this.btPath_Click);
			// 
			// tbSignalPath
			// 
			this.tbSignalPath.AllowDrop = true;
			this.tbSignalPath.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			this.tbSignalPath.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystemDirectories;
			this.tbSignalPath.Location = new System.Drawing.Point(15, 112);
			this.tbSignalPath.Name = "tbSignalPath";
			this.tbSignalPath.Size = new System.Drawing.Size(394, 23);
			this.tbSignalPath.TabIndex = 11;
			// 
			// lbSignalPath
			// 
			this.lbSignalPath.AutoSize = true;
			this.lbSignalPath.Location = new System.Drawing.Point(12, 95);
			this.lbSignalPath.Name = "lbSignalPath";
			this.lbSignalPath.Size = new System.Drawing.Size(133, 14);
			this.lbSignalPath.TabIndex = 10;
			this.lbSignalPath.Text = "实时状态输出路径：";
			// 
			// DlgSettings
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(502, 316);
			this.Controls.Add(this.btSignalPath);
			this.Controls.Add(this.tbSignalPath);
			this.Controls.Add(this.lbSignalPath);
			this.Controls.Add(this.btAlarmPath);
			this.Controls.Add(this.tbAlarmPath);
			this.Controls.Add(this.lbAlarmPath);
			this.Controls.Add(this.tbAlarm);
			this.Controls.Add(this.lbAlarm);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOk);
			this.Controls.Add(this.btLotSumPath);
			this.Controls.Add(this.tbLotSumPath);
			this.Controls.Add(this.lbLotSumPath);
			this.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Name = "DlgSettings";
			this.Text = "设置";
			this.Load += new System.EventHandler(this.DlgSettings_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label lbLotSumPath;
		public System.Windows.Forms.TextBox tbLotSumPath;
		private System.Windows.Forms.Button btLotSumPath;
		private System.Windows.Forms.Button btAlarmPath;
		public System.Windows.Forms.TextBox tbAlarmPath;
		private System.Windows.Forms.Label lbAlarmPath;
		private System.Windows.Forms.Button btSignalPath;
		public System.Windows.Forms.TextBox tbSignalPath;
		private System.Windows.Forms.Label lbSignalPath;
		private System.Windows.Forms.Label lbAlarm;
		public System.Windows.Forms.TextBox tbAlarm;
		private System.Windows.Forms.Button btnOk;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.FolderBrowserDialog fbDlg1;
	}
}