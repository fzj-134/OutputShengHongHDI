﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;
using Pub;

namespace Output
{
	class Log
	{
		private IniFiles Ini = null;
		private string Name = "Log";
		private string Path = "";		// 保存路径
		private uint No = 1;			// 当前序号
		private uint Limit = 100;		// 保留连续文件数量
		private uint Size = 4096 * 1024;// 单个文件的大小
		private Encoding ec = Encoding.Unicode;	// 采用Unicode编码

		public Log(IniFiles ini, string path, string name)
		{
			if(ini != null)
			{
				Ini = ini;
				Name = name;
				Path = path + Ini.ReadString(Name, "Sub", "Log") + @"\";
				No = (uint)Ini.ReadInteger(Name, "No", 0);
				Limit = (uint)Ini.ReadInteger(Name, "Limit", (int)Limit);
				Size = (uint)Ini.ReadInteger(Name, "Size", (int)Size);

				try
				{
					Directory.CreateDirectory(Path);
				}
				catch
				{

				}
			}
		}

		private string GetLogFilename(uint no)
		{
			return Path + Name + no.ToString() + ".log";
		}

		public string GetLogFilename()
		{
			string logFilename = GetLogFilename(No);
			// 检查当前日志是否超文件大小限制
			if(File.Exists(logFilename))
			{
				try
				{
					FileInfo fi = new FileInfo(logFilename);
					if (fi.Length >= Size)
					{
						No++;
						logFilename = GetLogFilename(No - Limit);
						File.Delete(logFilename);
						logFilename = GetLogFilename(No);
						Ini.WriteString(Name, "No", No.ToString());
					}
				}
				catch{ }
			}
			return logFilename;
		}

		public void WriteLine(string str)
		{
			using(
				StreamWriter sw =
					new StreamWriter(GetLogFilename(), true, ec))
			{
				sw.WriteLine(str);
			}
		}

		// 输出异常和附加消息，带时间标签
		public void Write(Exception e, string msg)
		{
			using(StreamWriter sw = new StreamWriter(GetLogFilename(), true, ec))
			{
				sw.WriteLine(DateTime.Now.ToString("MM-dd HH:mm:ss ") + e.Message);
				if(msg != null && msg.Length != 0)
					sw.WriteLine(msg);
				sw.WriteLine("类型：" + e.GetType().Name);
				sw.WriteLine(e.StackTrace);
				sw.WriteLine();
			}
		}

		public void Write(string s, string msg)
		{
			using (StreamWriter sw = new StreamWriter(GetLogFilename(), true, ec))
			{
				sw.WriteLine(DateTime.Now.ToString("MM-dd HH:mm:ss ") + s);
				if (msg != null && msg.Length != 0)
					sw.WriteLine(msg);
				sw.WriteLine();
			}
		}

		public void Write(string str)
        {
            using (StreamWriter sw = new StreamWriter(GetLogFilename(), true, ec))
            {
                sw.WriteLine(DateTime.Now.ToString("MM-dd HH:mm:ss ") + str);
                sw.WriteLine();
            }
        }
	}
}
