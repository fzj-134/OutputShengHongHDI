﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;
using System.Runtime.InteropServices;
using System.Collections;
using System.Collections.Specialized;
using System.Threading;

namespace Pub
{
	/// <summary>
	/// IniFiles的类
	/// </summary>
	public class IniFiles
	{
		// 写入超时设置，有时配置文件被锁定导致写入失败，在超时时间内反复
		int Timeout = 1500;		// 毫秒

		public string FileName; // INI文件名
		// 声明读写INI文件的API函数
		[DllImport("KERNEL32.DLL", EntryPoint = "WritePrivateProfileStringW", CharSet = CharSet.Unicode)]
		private static extern bool WritePrivateProfileString(string lpAppName, string lpKeyName, string lpValue, string lpFileName);
		[DllImport("KERNEL32.DLL", EntryPoint = "GetPrivateProfileStringW", CharSet = CharSet.Unicode)]
		private static extern int GetPrivateProfileString(string lpAppName, string lpKeyName, string lpDefault, byte[] lpReturnedString, int nSize, string lpFileName);
		[DllImport("KERNEL32.DLL", EntryPoint = "GetPrivateProfileSectionW", CharSet = CharSet.Unicode)]
		private static extern int GetPrivateProfileSection(string lpAppName, byte[] lpReturnedString, int nSize, string lpFileName);

		// 类的构造函数，传递INI文件名
		public IniFiles(string AFileName)
		{
			// 判断文件是否存在
			FileInfo fileInfo = new FileInfo(AFileName);
			//Todo:搞清枚举的用法
			//if ((!fileInfo.Exists))
			//{ //|| (FileAttributes.Directory in fileInfo.Attributes))
			//   //文件不存在，建立文件
			//   System.IO.StreamWriter sw = new System.IO.StreamWriter(AFileName, false, System.Text.Encoding.Default);
			//   try
			//   {
			//      sw.Write("#Ini file");
			//      sw.Close();
			//   }

			//   catch
			//   {
			//      throw (new ApplicationException("Ini file does not exist"));
			//   }
			//}
			//必须是完全路径，不能是相对路径
			FileName = fileInfo.FullName;
		}

		// 写INI文件
		public void WriteString(string Section, string Ident, string Value)
		{
			int timeout = 0;
			while (!WritePrivateProfileString(Section, Ident, Value, FileName) &&
				timeout < Timeout)
			{
				Thread.Sleep(50);
				timeout += 50;
			}
			if(timeout >= Timeout)
				throw (new ApplicationException("Write INI file error"));
		}

		// 读取INI文件指定
		public string ReadString(string Section, string Ident, string Default)
		{
			Byte[] Buffer = new Byte[65535];
			int bufLen = GetPrivateProfileString(Section, Ident, Default, Buffer, Buffer.GetUpperBound(0), FileName);
			// 因导入多字节版本的INI处理函数，读取出来的字符串为Unicode编码，多字节版本兼容ASCII和Unicode文件
			// ASCII文件只能兼容系统默认语言，例如简体中文系统支持简体中文
			// 注意：返回的字符串长度为双字节长度，用Byte数组时，长度需要*2
			string s = Encoding.GetEncoding(1200).GetString(Buffer, 0, bufLen * 2);
			return s;
		}

		public string ReadPath(string Section, string Ident, string Default)
		{
			string s = ReadString(Section, Ident, Default);
			if (s.Length > 0 && s.Substring(s.Length - 1) != @"\")
				s += @"\";
			return s;
		}

		// 读整数
		public int ReadInteger(string Section, string Ident, int Default)
		{
			string intStr = ReadString(Section, Ident, Convert.ToString(Default));
			try
			{
				return Convert.ToInt32(intStr);

			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
				return Default;
			}
		}

		// 写整数
		public void WriteInteger(string Section, string Ident, int Value)
		{
			WriteString(Section, Ident, Value.ToString());
		}

		// 读布尔
		public bool ReadBool(string Section, string Ident, bool Default)
		{
			try
			{
				return Convert.ToBoolean(ReadString(Section, Ident, Convert.ToString(Default)));
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
				return Default;
			}
		}

		// 写布尔
		public void WriteBool(string Section, string Ident, bool Value)
		{
			WriteString(Section, Ident, Convert.ToString(Value));
		}

		// 读取数字方式的BOOL
		public bool ReadBOOL(string Section, string Ident, bool Default)
		{
			return ReadInteger(Section, Ident, Default ? 1 : 0) != 0;
		}

		public void WriteBOOL(string Section, string Ident, bool Value)
		{
			WriteInteger(Section, Ident, Value ? 1 : 0);
		}

		// 读浮点数字
		public float ReadFloat(string Section, string Ident, float Default)
		{
			string s = ReadString(Section, Ident, Default.ToString());
			float v;
			return float.TryParse(s, out v) ? v : Default;
		}

		// 写浮点数字
		public void WriteFloat(string Section, string Ident, float Value)
		{
			WriteString(Section, Ident, Value.ToString("0.0000000"));
		}

		// 读时间
		public DateTime ReadDateTime(string Section, string Ident, string Default = "")
		{
			string s = ReadString(Section, Ident, Default);
			DateTime v;
			DateTime.TryParse(s, out v);
			return v;
		}

		// 写时间
		public void WriteDateTime(string Section, string Ident, DateTime value)
		{
			WriteString(Section, Ident, value.ToString("yyyy/MM/dd HH:mm:ss.FFF"));
		}

		// 从Ini文件中，将指定的Section名称中的所有Ident添加到列表中
		public void ReadSectionKeys(string Section, StringCollection Idents)
		{
			Byte[] Buffer = new Byte[65535];
			//Idents.Clear();

			int bufLen = GetPrivateProfileString(Section, null, null, Buffer, Buffer.GetUpperBound(0),
			 FileName);
			// 对Section进行解析
			GetStringsFromBuffer(Buffer, bufLen, Idents);
		}

		private void GetStringsFromBuffer(Byte[] Buffer, int bufLen, StringCollection Strings)
		{
			Strings.Clear();
			if (bufLen != 0)
			{
				int start = 0;
				for (int i = 0; i < bufLen * 2; i += 2)
				{
					if ((Buffer[i] == 0) && (Buffer[i + 1] == 0) &&
						((i - start) > 0))
					{
						String s = Encoding.GetEncoding(1200).GetString(Buffer, start, i - start);
						Strings.Add(s);
						start = i + 2;
					}
				}
			}
		}

		private void GetNamedStringsFromBuffer(Byte[] Buffer, int bufLen, NameValueCollection Strings)
		{
			Strings.Clear();
			if (bufLen != 0)
			{
				int start = 0;
				for (int i = 0; i < bufLen * 2; i += 2)
				{
					if ((Buffer[i] == 0) && (Buffer[i + 1] == 0) &&
						((i - start) > 0))
					{
						String s = Encoding.GetEncoding(1200).GetString(Buffer, start, i - start);
						int a = s.IndexOf('=');
						if(a != -1)
							Strings.Add(s.Substring(0, a), s.Substring(a + 1));
						start = i + 2;
					}
				}
			}
		}

		// 读取指定的Section的所有Key/Value到列表中，NameValueCollection按添加顺序枚举元素
		public void ReadSection(string Section, NameValueCollection Value)
		{
			byte[] buffer = new byte[65535];
			int bufLen = GetPrivateProfileSection(Section, buffer, 65535, FileName);
			GetNamedStringsFromBuffer(buffer, bufLen, Value);
		}

		// 从Ini文件中，读取所有的Sections的名称
		public void ReadSections(StringCollection SectionList)
		{
			// Note:必须得用Bytes来实现，StringBuilder只能取到第一个Section
			byte[] Buffer = new byte[65535];
			int bufLen = GetPrivateProfileString(null, null, null, Buffer, Buffer.GetUpperBound(0), FileName);
			GetStringsFromBuffer(Buffer, bufLen, SectionList);
		}

		////读取指定的Section的所有Value到列表中，
		//public void ReadSectionValues(string Section, NameValueCollection Values,char splitString)
		//{　 string sectionValue;
		//　　string[] sectionValueSplit;
		//　　StringCollection KeyList = new StringCollection();
		//　　ReadSection(Section, KeyList);
		//　　Values.Clear();
		//　　foreach (string key in KeyList)
		//　　{
		//　　　　sectionValue=ReadString(Section, key, "");
		//　　　　sectionValueSplit=sectionValue.Split(splitString);
		//　　　　Values.Add(key, sectionValueSplit[0].ToString(),sectionValueSplit[1].ToString());

		//　　}
		//}

		// 清除某个Section
		public void EraseSection(string Section)
		{
			WriteString(Section, null, null);
		}

		// 删除某个Section下的键
		public void DeleteKey(string Section, string Ident)
		{
			WritePrivateProfileString(Section, Ident, null, FileName);
		}

		// Note:对于Win9X，来说需要实现UpdateFile方法将缓冲中的数据写入文件
		// 在Win NT, 2000和XP上，都是直接写文件，没有缓冲，所以，无须实现UpdateFile
		// 执行完对Ini文件的修改之后，应该调用本方法更新缓冲区。
		public void UpdateFile()
		{
			WritePrivateProfileString(null, null, null, FileName);
		}

		// 检查某个Section下的某个键值是否存在
		public bool ValueExists(string Section, string Ident)
		{
			//
			StringCollection Idents = new StringCollection();
			ReadSectionKeys(Section, Idents);
			return Idents.IndexOf(Ident) > -1;
		}

		// 确保资源的释放
		~IniFiles()
		{
			UpdateFile();
		}
	}
}
