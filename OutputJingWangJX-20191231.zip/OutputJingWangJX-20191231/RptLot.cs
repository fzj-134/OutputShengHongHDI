﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Windows.Forms;
using System.IO;
using System.Collections.Specialized;

using Pub;
using Report;

namespace Output
{
	class RptLot
	{
		string outPath;
		string lot;
		// 是否区分大小写
		StringComparer ic = StringComparer.InvariantCulture;

		class NoCompare : IComparer<string>
		{
			public int Compare(string x, string y)
			{
				int ix, iy;
				if(int.TryParse(x, out ix) && int.TryParse(y, out iy))
				{ 
					if(ix < iy)
						return -1;
					else if(ix == iy)
						return 0;
					else
						return 1;
				}
				else
					return x.CompareTo(y);
			}
		}

		class Record
		{
			public int sides;
			public int sets;
			public int setFailds;
			public int defects;
			public int[] fields;
			public DateTime start;
		}

		class Set
		{
			public string op;
			public int sets;
			public int setFailds;
		}

		Dictionary<string, int> jobSet = null;

		// 客户自定义缺点ID顺序列表
		public List<string> custIds = new List<string>();
		// 客户自定义缺点名称字典
		public StringDictionary custCls = new StringDictionary();
		// 每AOI主机类型的缺点类型客户自定义ID列表中序号字典
		//                主机类型ID       缺点类型ID
		//                                        客户自定义ID列表序号
		public Dictionary<int, Dictionary<string, int>> srvCustCls = new Dictionary<int, Dictionary<string, int>>();

		protected void InitProgressBar(ProgressBar bar, int max)
		{
			bar.Value = 0;
			bar.Minimum = 0;
			bar.Maximum = max;
			bar.Step = max / 100;            // 重绘步值
			if (bar.Step == 0)
				bar.Step = 1;
		}

		public RptLot(string path, string lot)
		{
			this.lot = lot;
			outPath = path;
			jobSet = new Dictionary<string, int>();

			char[] split = new char[] { ',' };
			IniFiles custDc = new IniFiles(path + "dc.ini");
			// 读取客户自定义类型
			{
				// keys中ID顺序为输出顺序
				string keys = custDc.ReadString("Cust", "Keys", "");
				string[] ks = keys.Split(split, StringSplitOptions.RemoveEmptyEntries);
				custIds.AddRange(ks);
				foreach (string s in ks)
				{
					string name = custDc.ReadString("Cust", "n" + s, "");
					custCls[s] = name == "" ? s : name;
				}
			}
			// 读取各AOI的缺点客户自定义ID
			for (int i = 0; i < 100; i++)
			{
				Dictionary<string, int> srv = new Dictionary<string, int>();
				string section = "AT" + i.ToString();
				string keys = custDc.ReadString(section, "Keys", "");
				string[] ks = keys.Split(split, StringSplitOptions.RemoveEmptyEntries);
				foreach (string s in ks)
				{
					string custDcId = custDc.ReadString(section, "c" + s, "");
					int custDcIndex = custIds.FindIndex(id => id == custDcId);
					srv[s] = custDcIndex;
				}
				srvCustCls[i] = srv;
			}
		}



		public void Generate(InspectFiles ifs, Dictionary<string, int> servers, ProgressBar bar, string path)
		{
			InitProgressBar(bar, ifs.files.Count);

			DateTime now = DateTime.Now;
			string sNow1 = now.ToString(Common.dtFmt2);
			string sNow2 = now.ToString(Common.dtFmt1);
			string tmpFile = outPath + "SINGLETRACEDATA_" + sNow1 + ".csv";
			string dstFile = path + "SINGLETRACEDATA_" + sNow1 + ".csv";

			StreamWriter sw = new StreamWriter(tmpFile, true, Common.eCust);
			if(Common.fieldTitle)
			{
				string[] titles = new string[9];
				titles[0] = "ID";
				titles[1] = "CONTAINER";
				titles[2] = "ORDER";
				titles[3] = "ITEMCODE";
				titles[4] = "ITEMDES";
				titles[5] = "UOM";
				titles[6] = "ITEMVALUE";
				titles[7] = "ISOK";
				titles[8] = "CREATETIME";
				string titleline = Common.GetLine(titles);
				sw.WriteLine(titleline);
			}
			int autoid = 1;

			// Panel序号OK字典
			Dictionary<string, bool> panels = new Dictionary<string, bool>();
			Dictionary<string, Record> panelWorks = new Dictionary<string, Record>();
			Record sum = new Record();
			sum.fields = new int[custIds.Count];
			while (ifs.files.Count > 0)
			{
				// 取得第一条记录的machine/server/job/layer/day信息，将这些信息的记录统计至一条记录
				InspectFile cur = ifs.files.Peek();

				// 不统计已经删除的服务器名数据
				if (servers.ContainsKey(cur.server) == false)
				{
					ifs.files.Dequeue();
					continue;
				}

				// 读取各vrs的set数量
				if (jobSet.ContainsKey(cur.job) == false)
					try
					{
						StreamReader sr = new StreamReader(cur.file.Substring(0, cur.file.IndexOf("\\PCB\\") + 1) + "SET\\" + cur.job + ".csv");
						jobSet[cur.job] = int.Parse(sr.ReadLine());
						sr.Close();
					}
					catch { }

				int aoi = servers[cur.server];
				SumDaliyData(sum, ifs, srvCustCls[aoi], panels, panelWorks);
				bar.Value++;
			}

			if(panels.Count > 0)
			{
				string[] fields = new string[9];
				fields[0] = "";			// 自动增长Id
				fields[1] = lot;		// Lot
				fields[2] = "";			// Order固定输出1
				fields[3] = "";			// ItemCode
				fields[4] = "";			// ItemDes
				fields[5] = "SET";		// UOM单位
				fields[6] = "";			// ItemValue
				fields[7] = "";			// IsOK
				fields[8] = sNow2;		// CreateTime
				string line;

				IEnumerable<KeyValuePair<string, Record>> works = panelWorks.OrderBy(work => work.Key, new NoCompare());
				foreach(KeyValuePair<string, Record> work in works)
				{
					fields[2] = work.Key;
					for (int i = 0; i < custIds.Count; i++)
					{
						fields[0] = (autoid++).ToString();
						string id = custIds[i];
						fields[3] = id;
						fields[4] = custCls[id];
						fields[6] = work.Value.fields[i].ToString();
						line = Common.GetLine(fields);
						sw.WriteLine(line);
					}
				}

				fields[2] = "";
				if(Common.detailSum)
				{
					for (int i = 0; i < custIds.Count; i++)
					{
						fields[0] = (autoid++).ToString();
						string id = custIds[i];
						fields[3] = id;
						fields[4] = custCls[id];
						fields[6] = sum.fields[i].ToString();
						line = Common.GetLine(fields);
						sw.WriteLine(line);
					}
				}

				int okPanels = panels.Sum(p => p.Value ? 1 : 0);
				fields[0] = (autoid++).ToString();
				fields[3] = "SECOND_NG_NUM";
				fields[4] = "二次不良板数";
				fields[5] = "pnl";
				fields[6] = (panels.Count - okPanels).ToString();
				line = Common.GetLine(fields);
				sw.WriteLine(line);

				fields[0] = (autoid++).ToString();
				double percent = 0.0d;
				if (panels.Count != 0)
					percent = 100.0d * okPanels / panels.Count;
				fields[3] = "SECOND_OK_RATE";
				fields[4] = "二次良率";
				fields[5] = "%";
				fields[6] = percent.ToString("0.00");
				line = Common.GetLine(fields);
				sw.WriteLine(line);

				fields[0] = (autoid++).ToString();
				percent = 0.0d;
				if (sum.sets != 0)
					percent = 100.0d * (sum.sets - sum.setFailds) / sum.sets;
				fields[3] = "SET_OK_RATE";
				fields[4] = "SET良率";
				fields[5] = "%";
				fields[6] = percent.ToString("0.00");
				line = Common.GetLine(fields);
				sw.WriteLine(line);
			}

			sw.Close();
			Directory.CreateDirectory(path);
			File.Move(tmpFile, dstFile);
			bar.Value = bar.Maximum;
		}

		bool SumDaliyData(Record r, InspectFiles ifs, Dictionary<string, int> defectTypes, Dictionary<string, bool> panels, Dictionary<string, Record> panelWorks)
		{
			// 统计ifs队列第一条记录中的csv文件中的数据，并将记录从队列中删除

			if (ifs.files.Count == 0)
				return false;

			InspectFile cur = ifs.files.Dequeue();

			// 有效序号列表，有时操作员只检查了一面，这些不完事检查记录不进行统计，因为这些板应该是有问题需要重新在AOI上扫描，统计这些记录会影响报表准确度
			string path;
			int m = cur.file.LastIndexOf('\\');
			path = m != -1 ? cur.file.Substring(0, m + 1).Replace(@"\PCB\", @"\Panel\") : "";
			//                                     没有layer字段
			path += cur.server + "#" + cur.job + "#" + cur.stage + "#" + cur.batch + "#" + cur.day + ".csv";
			try
			{
				// panel记录必须是序号\t1(0)格式，例如：
				// 1424	1
				// 1425	0
				using(StreamReader sr = new StreamReader(path))
				{
					foreach (string s in sr.ReadToEnd().Split(new String[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries))
					{
						string[] ss = s.Split('\t');
						panels[ss[0]] = (int.Parse(ss[1]) == 0);
					}
				}
			}
			catch
			{ }

			// 因操作员在报表中是关键字，故先读取，以及set数据
			//         no
			Dictionary<string, Set> noSet = new Dictionary<string, Set>();
			char[] split = new char[] { '\t' };
			try
			{
				// 从set记录中查找
				int set = 0;
				jobSet.TryGetValue(cur.job, out set);

				using(StreamReader sr = new StreamReader(cur.file.Replace("\\PCB\\", "\\SET\\")))
				{
					// 文件序号\t操作员\tSet\tFaild
					while (sr.EndOfStream == false)
					{
						string[] fields = sr.ReadLine().Split(split, StringSplitOptions.None);
						if (panels.ContainsKey(fields[0]) == false)
							continue;   // 不统计无效板序号

						if (fields.Length >= 4)
						{
							Set s = new Set();
							noSet[fields[0]] = s;

							s.op = fields[1];
							if (set == 0)
								if (int.TryParse(fields[2], out set))
									jobSet[cur.job] = set;
							s.sets = set;
							int setFailds = 0;
							int.TryParse(fields[3], out setFailds);
							s.setFailds = setFailds;
						}
					}
				}
			}
			catch
			{ }

			split = new char[] { ',' };
			using(StreamReader sr = new StreamReader(cur.file))
			{
				if (sr.EndOfStream == false)
				{
					// 第一行为字段定义
					// 文件序号,开始,结束,缺点类型内部Id列表
					string[] fieldIds = sr.ReadLine().Split(split, StringSplitOptions.None);
					int[] fieldIdx = new int[fieldIds.Length];
					// 查找缺点类型在报表标题中的自定义顺序
					// 跳过-1和0，如果有定义星号列，则将所有未列出的类型汇总到星号，即其它列表
					int idx = 0;
					for (int i = 5; i < fieldIds.Length; i++)
						fieldIdx[i] = defectTypes.TryGetValue(fieldIds[i], out idx) ? idx : (
							defectTypes.TryGetValue("*", out idx) ? idx : -1);

					while (sr.EndOfStream == false)
					{
						string[] fields = sr.ReadLine().Split(split, StringSplitOptions.None);
						if (fieldIds.Length <= 3)
							continue;	// 不统计无效记录
						if (panels.ContainsKey(fields[0]) == false)
							continue;   // 不统计无效板序号

						Record w;
						if(panelWorks.TryGetValue(fields[0], out w))
						{
							DateTime dt;
							if(DateTime.TryParse(fields[1], out dt) && dt < w.start)
								w.start = dt;
						}
						else
						{
							w = new Record();
							w.fields = new int[custIds.Count];
							DateTime.TryParse(fields[1], out w.start);
							panelWorks[fields[0]] = w;
						}


						int rectotal = 0;
						for (int i = 5; i < fields.Length; i++)
						{
							if (fieldIdx[i] == -1)
								continue;	// 不统计未定义客户自定义类型Id

							int count = 0; int.TryParse(fields[i], out count);
							rectotal += count;
							r.fields[fieldIdx[i]] += count;
							w.fields[fieldIdx[i]] += count;
						}

						r.sides++;
						r.defects += rectotal;
						w.sides++;
						w.defects += rectotal;

						Set set = null;
						noSet.TryGetValue(fields[0], out set);
						if (set != null)
						{
							r.sets += set.sets;
							r.setFailds += set.setFailds;
							w.sets += set.sets;
							w.setFailds += set.setFailds;
						}
					}
				}
			}

			return true;
		}
	}
}
