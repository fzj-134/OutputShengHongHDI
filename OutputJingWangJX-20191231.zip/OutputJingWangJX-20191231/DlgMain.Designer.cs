﻿namespace Output
{
	partial class DlgMain
	{
		/// <summary>
		/// 必需的设计器变量。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 清理所有正在使用的资源。
		/// </summary>
		/// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows 窗体设计器生成的代码

		/// <summary>
		/// 设计器支持所需的方法 - 不要
		/// 使用代码编辑器修改此方法的内容。
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DlgMain));
            this.lblVersion2 = new System.Windows.Forms.Label();
            this.lblVersion = new System.Windows.Forms.Label();
            this.btnSettings = new System.Windows.Forms.Button();
            this.lblLotSum = new System.Windows.Forms.Label();
            this.pgsBar1 = new System.Windows.Forms.ProgressBar();
            this.gbAlarm = new System.Windows.Forms.GroupBox();
            this.cbAlarm1 = new System.Windows.Forms.CheckBox();
            this.ilAlarmState = new System.Windows.Forms.ImageList(this.components);
            this.cbAlarm2 = new System.Windows.Forms.CheckBox();
            this.cbAlarm3 = new System.Windows.Forms.CheckBox();
            this.fswSignal = new System.IO.FileSystemWatcher();
            this.gbSignal = new System.Windows.Forms.GroupBox();
            this.cbSignal1 = new System.Windows.Forms.CheckBox();
            this.cbSignal2 = new System.Windows.Forms.CheckBox();
            this.cbSignal3 = new System.Windows.Forms.CheckBox();
            this.buttonLoad = new System.Windows.Forms.Button();
            this.timerStart = new System.Windows.Forms.Timer(this.components);
            this.buttonUpload = new System.Windows.Forms.Button();
            this.fswData = new System.IO.FileSystemWatcher();
            this.gbAlarm.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fswSignal)).BeginInit();
            this.gbSignal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fswData)).BeginInit();
            this.SuspendLayout();
            // 
            // lblVersion2
            // 
            this.lblVersion2.AutoSize = true;
            this.lblVersion2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblVersion2.Location = new System.Drawing.Point(86, 10);
            this.lblVersion2.Name = "lblVersion2";
            this.lblVersion2.Size = new System.Drawing.Size(98, 14);
            this.lblVersion2.TabIndex = 5;
            this.lblVersion2.Text = "00.00.00.0000";
            // 
            // lblVersion
            // 
            this.lblVersion.AutoSize = true;
            this.lblVersion.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblVersion.Location = new System.Drawing.Point(14, 10);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(56, 14);
            this.lblVersion.TabIndex = 4;
            this.lblVersion.Text = "版本号:";
            // 
            // btnSettings
            // 
            this.btnSettings.Location = new System.Drawing.Point(263, 4);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(87, 27);
            this.btnSettings.TabIndex = 6;
            this.btnSettings.Text = "设置";
            this.btnSettings.UseVisualStyleBackColor = true;
            this.btnSettings.Visible = false;
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
            // 
            // lblLotSum
            // 
            this.lblLotSum.AutoSize = true;
            this.lblLotSum.Location = new System.Drawing.Point(12, 241);
            this.lblLotSum.Name = "lblLotSum";
            this.lblLotSum.Size = new System.Drawing.Size(84, 14);
            this.lblLotSum.TabIndex = 7;
            this.lblLotSum.Text = "LOT汇总数据";
            this.lblLotSum.Visible = false;
            // 
            // pgsBar1
            // 
            this.pgsBar1.Location = new System.Drawing.Point(2, 280);
            this.pgsBar1.Name = "pgsBar1";
            this.pgsBar1.Size = new System.Drawing.Size(370, 20);
            this.pgsBar1.TabIndex = 18;
            this.pgsBar1.Visible = false;
            // 
            // gbAlarm
            // 
            this.gbAlarm.Controls.Add(this.cbAlarm1);
            this.gbAlarm.Controls.Add(this.cbAlarm2);
            this.gbAlarm.Controls.Add(this.cbAlarm3);
            this.gbAlarm.Location = new System.Drawing.Point(17, 126);
            this.gbAlarm.Name = "gbAlarm";
            this.gbAlarm.Size = new System.Drawing.Size(340, 78);
            this.gbAlarm.TabIndex = 19;
            this.gbAlarm.TabStop = false;
            this.gbAlarm.Text = "相机：";
            this.gbAlarm.Visible = false;
            // 
            // cbAlarm1
            // 
            this.cbAlarm1.Appearance = System.Windows.Forms.Appearance.Button;
            this.cbAlarm1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbAlarm1.ImageIndex = 1;
            this.cbAlarm1.ImageList = this.ilAlarmState;
            this.cbAlarm1.Location = new System.Drawing.Point(6, 22);
            this.cbAlarm1.Name = "cbAlarm1";
            this.cbAlarm1.Size = new System.Drawing.Size(105, 38);
            this.cbAlarm1.TabIndex = 0;
            this.cbAlarm1.Text = "连接异常";
            this.cbAlarm1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cbAlarm1.UseVisualStyleBackColor = true;
            this.cbAlarm1.Visible = false;
            this.cbAlarm1.CheckedChanged += new System.EventHandler(this.cbAlarm_CheckedChanged);
            this.cbAlarm1.Click += new System.EventHandler(this.cbAlarm_Click);
            // 
            // ilAlarmState
            // 
            this.ilAlarmState.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ilAlarmState.ImageStream")));
            this.ilAlarmState.TransparentColor = System.Drawing.Color.Transparent;
            this.ilAlarmState.Images.SetKeyName(0, "AlarmGray32.png");
            this.ilAlarmState.Images.SetKeyName(1, "AlarmGreen32.png");
            this.ilAlarmState.Images.SetKeyName(2, "AlarmRed232.png");
            // 
            // cbAlarm2
            // 
            this.cbAlarm2.Appearance = System.Windows.Forms.Appearance.Button;
            this.cbAlarm2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbAlarm2.ImageIndex = 1;
            this.cbAlarm2.ImageList = this.ilAlarmState;
            this.cbAlarm2.Location = new System.Drawing.Point(117, 22);
            this.cbAlarm2.Name = "cbAlarm2";
            this.cbAlarm2.Size = new System.Drawing.Size(105, 38);
            this.cbAlarm2.TabIndex = 1;
            this.cbAlarm2.Text = "运动异常";
            this.cbAlarm2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cbAlarm2.UseVisualStyleBackColor = true;
            this.cbAlarm2.Visible = false;
            this.cbAlarm2.CheckedChanged += new System.EventHandler(this.cbAlarm_CheckedChanged);
            this.cbAlarm2.Click += new System.EventHandler(this.cbAlarm_Click);
            // 
            // cbAlarm3
            // 
            this.cbAlarm3.Appearance = System.Windows.Forms.Appearance.Button;
            this.cbAlarm3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbAlarm3.ImageIndex = 1;
            this.cbAlarm3.ImageList = this.ilAlarmState;
            this.cbAlarm3.Location = new System.Drawing.Point(228, 22);
            this.cbAlarm3.Name = "cbAlarm3";
            this.cbAlarm3.Size = new System.Drawing.Size(105, 38);
            this.cbAlarm3.TabIndex = 2;
            this.cbAlarm3.Text = "相机异常";
            this.cbAlarm3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cbAlarm3.UseVisualStyleBackColor = true;
            this.cbAlarm3.Visible = false;
            this.cbAlarm3.CheckedChanged += new System.EventHandler(this.cbAlarm_CheckedChanged);
            this.cbAlarm3.Click += new System.EventHandler(this.cbAlarm_Click);
            // 
            // fswSignal
            // 
            this.fswSignal.EnableRaisingEvents = true;
            this.fswSignal.Filter = "Signal.ini";
            this.fswSignal.NotifyFilter = System.IO.NotifyFilters.LastWrite;
            this.fswSignal.SynchronizingObject = this;
            this.fswSignal.Changed += new System.IO.FileSystemEventHandler(this.fswSignal_Changed);
            // 
            // gbSignal
            // 
            this.gbSignal.Controls.Add(this.cbSignal1);
            this.gbSignal.Controls.Add(this.cbSignal2);
            this.gbSignal.Controls.Add(this.cbSignal3);
            this.gbSignal.Location = new System.Drawing.Point(17, 42);
            this.gbSignal.Name = "gbSignal";
            this.gbSignal.Size = new System.Drawing.Size(340, 78);
            this.gbSignal.TabIndex = 20;
            this.gbSignal.TabStop = false;
            this.gbSignal.Text = "信号：";
            this.gbSignal.Visible = false;
            // 
            // cbSignal1
            // 
            this.cbSignal1.Appearance = System.Windows.Forms.Appearance.Button;
            this.cbSignal1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbSignal1.ImageIndex = 1;
            this.cbSignal1.ImageList = this.ilAlarmState;
            this.cbSignal1.Location = new System.Drawing.Point(6, 22);
            this.cbSignal1.Name = "cbSignal1";
            this.cbSignal1.Size = new System.Drawing.Size(105, 38);
            this.cbSignal1.TabIndex = 6;
            this.cbSignal1.Text = "设备待料";
            this.cbSignal1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cbSignal1.UseVisualStyleBackColor = true;
            this.cbSignal1.Visible = false;
            this.cbSignal1.CheckedChanged += new System.EventHandler(this.cbSignal_CheckedChanged);
            this.cbSignal1.Click += new System.EventHandler(this.cbSignal_Click);
            // 
            // cbSignal2
            // 
            this.cbSignal2.Appearance = System.Windows.Forms.Appearance.Button;
            this.cbSignal2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbSignal2.ImageIndex = 1;
            this.cbSignal2.ImageList = this.ilAlarmState;
            this.cbSignal2.Location = new System.Drawing.Point(117, 22);
            this.cbSignal2.Name = "cbSignal2";
            this.cbSignal2.Size = new System.Drawing.Size(105, 38);
            this.cbSignal2.TabIndex = 7;
            this.cbSignal2.Text = "总故障";
            this.cbSignal2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cbSignal2.UseVisualStyleBackColor = true;
            this.cbSignal2.Visible = false;
            this.cbSignal2.CheckedChanged += new System.EventHandler(this.cbSignal_CheckedChanged);
            this.cbSignal2.Click += new System.EventHandler(this.cbSignal_Click);
            // 
            // cbSignal3
            // 
            this.cbSignal3.Appearance = System.Windows.Forms.Appearance.Button;
            this.cbSignal3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbSignal3.ImageIndex = 1;
            this.cbSignal3.ImageList = this.ilAlarmState;
            this.cbSignal3.Location = new System.Drawing.Point(228, 22);
            this.cbSignal3.Name = "cbSignal3";
            this.cbSignal3.Size = new System.Drawing.Size(105, 38);
            this.cbSignal3.TabIndex = 8;
            this.cbSignal3.Text = "停线故障";
            this.cbSignal3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cbSignal3.UseVisualStyleBackColor = true;
            this.cbSignal3.Visible = false;
            this.cbSignal3.CheckedChanged += new System.EventHandler(this.cbSignal_CheckedChanged);
            this.cbSignal3.Click += new System.EventHandler(this.cbSignal_Click);
            // 
            // buttonLoad
            // 
            this.buttonLoad.Location = new System.Drawing.Point(263, 243);
            this.buttonLoad.Name = "buttonLoad";
            this.buttonLoad.Size = new System.Drawing.Size(87, 27);
            this.buttonLoad.TabIndex = 21;
            this.buttonLoad.Text = "加载";
            this.buttonLoad.UseVisualStyleBackColor = true;
            this.buttonLoad.Click += new System.EventHandler(this.buttonLoad_Click);
            // 
            // timerStart
            // 
            this.timerStart.Interval = 1000;
            this.timerStart.Tick += new System.EventHandler(this.timerStart_Tick);
            // 
            // buttonUpload
            // 
            this.buttonUpload.Location = new System.Drawing.Point(263, 210);
            this.buttonUpload.Name = "buttonUpload";
            this.buttonUpload.Size = new System.Drawing.Size(87, 27);
            this.buttonUpload.TabIndex = 22;
            this.buttonUpload.Text = "上传";
            this.buttonUpload.UseVisualStyleBackColor = true;
            this.buttonUpload.Click += new System.EventHandler(this.buttonUpload_Click);
            this.buttonUpload.MouseHover += new System.EventHandler(this.buttonUpload_MouseHover);
            // 
            // fswData
            // 
            this.fswData.EnableRaisingEvents = true;
            this.fswData.Filter = "*_?.txt";
            this.fswData.NotifyFilter = System.IO.NotifyFilters.FileName;
            this.fswData.SynchronizingObject = this;
            this.fswData.Created += new System.IO.FileSystemEventHandler(this.fswData_Created);
            // 
            // DlgMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(375, 303);
            this.Controls.Add(this.buttonUpload);
            this.Controls.Add(this.buttonLoad);
            this.Controls.Add(this.gbSignal);
            this.Controls.Add(this.gbAlarm);
            this.Controls.Add(this.pgsBar1);
            this.Controls.Add(this.lblLotSum);
            this.Controls.Add(this.btnSettings);
            this.Controls.Add(this.lblVersion2);
            this.Controls.Add(this.lblVersion);
            this.Font = new System.Drawing.Font("宋体", 10.5F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DlgMain";
            this.Text = "设备信号、数据交互工具";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Main_FormClosing);
            this.Load += new System.EventHandler(this.Main_Load);
            this.gbAlarm.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fswSignal)).EndInit();
            this.gbSignal.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fswData)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label lblVersion2;
		private System.Windows.Forms.Label lblVersion;
		private System.Windows.Forms.Button btnSettings;
		private System.Windows.Forms.Label lblLotSum;
		private System.Windows.Forms.ProgressBar pgsBar1;
		private System.Windows.Forms.GroupBox gbAlarm;
		private System.Windows.Forms.CheckBox cbAlarm1;
		private System.Windows.Forms.CheckBox cbAlarm2;
		private System.Windows.Forms.CheckBox cbAlarm3;
		private System.Windows.Forms.ImageList ilAlarmState;
		private System.IO.FileSystemWatcher fswSignal;
		private System.Windows.Forms.GroupBox gbSignal;
		private System.Windows.Forms.CheckBox cbSignal3;
		private System.Windows.Forms.CheckBox cbSignal2;
		private System.Windows.Forms.CheckBox cbSignal1;
        private System.Windows.Forms.Button buttonLoad;
        public System.Windows.Forms.Timer timerStart;
        private System.Windows.Forms.Button buttonUpload;
        private System.IO.FileSystemWatcher fswData;
    }
}

