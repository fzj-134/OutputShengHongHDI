﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Output
{
	public partial class DlgSettings : Form
	{
		public DlgSettings()
		{
			InitializeComponent();
		}

		private void btPath_Click(object sender, EventArgs e)
		{
			Button btn = (Button)sender;
			TextBox tb = null;
			switch(btn.Name)
			{
				case "btLotSumPath":
					tb = tbLotSumPath;
					break;
				case "btAlarmPath":
					tb = tbAlarmPath;
					break;
				case "btSignalPath":
					tb = tbSignalPath;
					break;
			}
			if(tb != null)
			{
				fbDlg1.SelectedPath = tb.Text;
				if(fbDlg1.ShowDialog(this) == DialogResult.OK)
					tb.Text = fbDlg1.SelectedPath;
			}
		}

		private void DlgSettings_Load(object sender, EventArgs e)
		{

		}

		private void btnOk_Click(object sender, EventArgs e)
		{
			int value = 0;
			int.TryParse(tbAlarm.Text, out value);
			if(value < 1 || value > 1000)
			{
				Color c = tbAlarm.BackColor;
				tbAlarm.BackColor = Color.Red;
				MessageBox.Show("上报数量必须在1~1000之间。");
				tbAlarm.Focus();
				tbAlarm.BackColor = c;
			}
			else
				DialogResult = DialogResult.OK;
		}
	}
}
