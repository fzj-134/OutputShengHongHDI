﻿using Pub;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Output
{
    #region 惠州胜宏科技
    public class ShengHong
    {
        #region 声明公共变量等实例参数
        /// <summary>
        /// 记录文件
        /// </summary>
        public static IniFiles timeIni { get; set; }

        /// <summary>
        /// oew.ini
        /// </summary>
        private IniFiles oewIni { get; set; }

        /// <summary>
        /// 是否待料
        /// </summary>
        public bool? WAT_TIMER = null;

        /// <summary>
        /// 待料时间
        /// </summary>
        private Stopwatch actrunStopwatch = new Stopwatch();

        /// <summary>
        /// 故障时间
        /// </summary>
        private Stopwatch faultStopwatch = new Stopwatch();

        /// <summary>
        /// 字典
        /// </summary>
        private Dictionary<string, int> Dic_EMERGENCYSTOP = new Dictionary<string, int>();

        /// <summary>
        /// 字典
        /// </summary>
        private Dictionary<string, int> Dic_STOPLINE = new Dictionary<string, int>();

        /// <summary>
        /// 字典
        /// </summary>
        private Dictionary<string, int> Dic_TOTALALARM = new Dictionary<string, int>();

        /// <summary>
        /// 字典
        /// </summary>
        public Dictionary<string, int> Dic_POEWR= new Dictionary<string, int>();

        /// <summary>
        /// 文件目录
        /// </summary>
        private string Path { get; set; }

        /// <summary>
        /// 总时间
        /// </summary>
        private int Runningtime = 720;

        /// <summary>
        /// ini待料时间
        /// </summary>
        public int Wat = 600000;

        /// <summary>
        /// ini上传时间
        /// </summary>
        public int upwat = 10000;

        public IniShift Tshift = new IniShift();

        public SharePath sharePath =new SharePath();

        public ShengHong()
        {
        }
        #endregion

        #region 加载设置
        /// <summary>
        /// 故障时间初始化设置
        /// </summary>
        /// <param name="filepath"></param>
        /// <param name="iniFiles"></param>
        /// <remarks>
        /// output.ini获取早班时间和晚班时间
        /// </remarks>
        public void Setting(string filepath, IniFiles iniFiles)
        {
            Path = filepath;
            oewIni = iniFiles;
            if (!File.Exists(filepath + "Time.ini"))
            {
                File.Create(filepath + "Time.ini");
            }
            timeIni = new IniFiles(filepath + "Time.ini");
            Tshift = IniShift.TimeiniShift(timeIni);
            Dic_EMERGENCYSTOP.Add("EMERGENCYSTOP", 0);
            Dic_STOPLINE.Add("STOPLINE", 0);
            Dic_TOTALALARM.Add("TOTALALARM", 0);
            Wat = timeIni.ReadInteger("Path", "wat", 600000);
            upwat = timeIni.ReadInteger("Path", "upwat", 10000);
            IniShift.CompareIniShift(ref Tshift, IniShift.OewiniShift(oewIni), timeIni);
            if (
                string.IsNullOrEmpty(timeIni.ReadString("Path", "Data", string.Empty))
                || string.IsNullOrEmpty(timeIni.ReadString("Path", "Signal", string.Empty))
                || string.IsNullOrEmpty(timeIni.ReadString("Path", "User", string.Empty)))
            {
            }
            else
            {
                sharePath = new SharePath(timeIni.ReadString("Path", "Data", string.Empty), timeIni.ReadString("Path", "Signal", string.Empty), timeIni.ReadString("Path", "Password", string.Empty), timeIni.ReadString("Path", "User", string.Empty));
            }
        }
        #endregion

        #region 统计故障总时间和生产总时间，关闭程序前记录到output.ini同级目录下的time.ini
        /// <summary>
        /// 时间
        /// </summary>
        /// <param name="signal">对象，信号</param>
        /// <param name="cbSignal2">CheckBox，总故障</param>
        /// <param name="cbSignal3">CheckBox，停线故障</param>
        /// <remarks>
        /// 统计故障时间
        /// </remarks>
        public void showFaulttime(Signal signal)
        {
            //TotalAlarm 设备总故障状态，signal.key，等于1设备开始故障，等于0设备停止故障
            //StopLine 设备重大故障(停线故障，signal.key，等于1设备开始故障，等于0设备停止故障
            //EmergencyStop 紧急按钮，signal.key，等于1设备开始故障，等于0设备停止故障
            if (signal.key == "TotalAlarm")
            {
                if (signal.value == 1 && Dic_TOTALALARM["TOTALALARM"] !=1)
                {
                    Dic_TOTALALARM["TOTALALARM"] = signal.value;
                    if (!faultStopwatch.IsRunning)
                    {
                        faultStopwatch.Start();
                    }
                }
                else if (signal.value == 0)
                {
                    timeiniWrite(key: signal.key);
                }
            }

            if (signal.key == "StopLine")
            {
                if (signal.value == 1 && Dic_STOPLINE["STOPLINE"] != 1)
                {
                    Dic_STOPLINE["STOPLINE"] = signal.value;
                    if (!faultStopwatch.IsRunning)
                    {
                        faultStopwatch.Start();
                    }
                }
                else if (signal.value == 0)
                {
                    timeiniWrite(key: signal.key);
                }
            }

            if (signal.key == "EmergencyStop")
            {
                if (signal.value == 1 && Dic_EMERGENCYSTOP["EMERGENCYSTOP"] != 1)
                {
                    Dic_EMERGENCYSTOP["EMERGENCYSTOP"] = signal.value;
                    if (!faultStopwatch.IsRunning)
                    {
                        faultStopwatch.Start();
                    }
                }
                else if (signal.value == 0)
                {
                    timeiniWrite(key: signal.key);
                }
            }

            //WAITMATERIAL 待料时间，signal.key，等于1设备开始运行，等于0设备停止运行
            if (signal.key == "WaitMaterial")
            {
                if (signal.value == 1 && !actrunStopwatch.IsRunning)
                {
                    actrunStopwatch.Start();
                }
                else if (signal.value == 0)
                {
                    timeiniWrite(key: signal.key);
                }
            }

            if (signal.key == "Working" && signal.value == 0)
            {
                WAT_TIMER = true;
            }

            if (signal.key == "Startup")
            {
                if (signal.value == 1)
                    WAT_TIMER = true;
            }
        }

        /// <summary>
        /// 输出总故障时间
        /// </summary>
        /// <remarks>
        /// timeIni里面记录总故障时间
        /// </remarks>
        public void timeiniWrite(string key ="")
        {
            switch (key)
            {
                case "StopLine":
                    if (Dic_STOPLINE["STOPLINE"] == 1)
                        Dic_STOPLINE["STOPLINE"] = 0;
                    if (Dic_TOTALALARM["TOTALALARM"] == 0 && Dic_STOPLINE["STOPLINE"]==0 && Dic_EMERGENCYSTOP["EMERGENCYSTOP"] == 0)
                    {
                        if (faultStopwatch.IsRunning)
                            faultStopwatch.Stop();
                        timeIni.WriteInteger("Fault", "fault", Convert.ToInt32(faultStopwatch.Elapsed.TotalSeconds) + Convert.ToInt32(timeIni.ReadString("Fault", "fault", "0")));
                        faultStopwatch.Reset();
                        WAT_TIMER = true;
                    }
                    break;
                case "TotalAlarm":
                    if (Dic_TOTALALARM["TOTALALARM"] == 1)
                        Dic_TOTALALARM["TOTALALARM"] = 0;
                    if (Dic_TOTALALARM["TOTALALARM"] == 0 && Dic_STOPLINE["STOPLINE"] == 0 && Dic_EMERGENCYSTOP["EMERGENCYSTOP"] == 0)
                    {
                        if (faultStopwatch.IsRunning)
                            faultStopwatch.Stop();
                        timeIni.WriteInteger("Fault", "fault", Convert.ToInt32(faultStopwatch.Elapsed.TotalSeconds) + Convert.ToInt32(timeIni.ReadString("Fault", "fault", "0")));
                        faultStopwatch.Reset();
                        WAT_TIMER = true;
                    }
                    break;
                case "EmergencyStop":
                    if (Dic_EMERGENCYSTOP["EMERGENCYSTOP"] == 1)
                        Dic_EMERGENCYSTOP["EMERGENCYSTOP"] = 0;
                    if (Dic_TOTALALARM["TOTALALARM"] == 0 && Dic_STOPLINE["STOPLINE"] == 0 && Dic_EMERGENCYSTOP["EMERGENCYSTOP"] == 0)
                    {
                        if (faultStopwatch.IsRunning)
                            faultStopwatch.Stop();
                        timeIni.WriteInteger("Fault", "fault", Convert.ToInt32(faultStopwatch.Elapsed.TotalSeconds) + Convert.ToInt32(timeIni.ReadString("Fault", "fault", "0")));
                        faultStopwatch.Reset();
                        WAT_TIMER = true;
                    }
                    break;
                case "WaitMaterial":
                    if (actrunStopwatch.IsRunning)
                        actrunStopwatch.Stop();
                    timeIni.WriteInteger("Fault", "actrun", Convert.ToInt32(actrunStopwatch.Elapsed.TotalSeconds) + Convert.ToInt32(timeIni.ReadString("Fault", "actrun", "0")));
                    actrunStopwatch.Reset();
                    WAT_TIMER = false;
                    break;
                case "":
                    if (actrunStopwatch.IsRunning)
                        actrunStopwatch.Stop();
                    timeIni.WriteInteger("Fault", "actrun", Convert.ToInt32(actrunStopwatch.Elapsed.TotalSeconds) + Convert.ToInt32(timeIni.ReadString("Fault", "actrun", "0")));
                    actrunStopwatch.Reset();
                    if (faultStopwatch.IsRunning)
                        faultStopwatch.Stop();
                    timeIni.WriteInteger("Fault", "fault", Convert.ToInt32(faultStopwatch.Elapsed.TotalSeconds) + Convert.ToInt32(timeIni.ReadString("Fault", "fault", "0")));
                    faultStopwatch.Reset();
                    break;
                default:
                    break;
            }
        }
        #endregion

        #region 输出RATEDATE+_+年月日时分秒毫秒+.csv
        /// <summary>
        /// 输出.csv文件
        /// </summary>
        /// <remarks>
        /// 输出RATEDATE+_+年月日时分秒毫秒+.csv，先保存在output.ini同级目录下面，再把文件转移到指定目录下面
        /// </remarks>
        public void Output(string alarmPath)
        {
            bool bofau = (faultStopwatch.IsRunning) ? true : false;
            if (bofau)
                faultStopwatch.Stop();
            bool boact = (actrunStopwatch.IsRunning) ? true : false;
            if (boact)
                actrunStopwatch.Stop();
            Aggrandizement aggment = CreateAggrandizement();
            string[] fields = new string[10];
            fields[0] = aggment.Id;
            fields[1] = aggment.Equip_no;
            fields[2] = aggment.Shift;
            fields[3] = aggment.Running_time;
            fields[4] = aggment.Act_Running_time;
            fields[5] = aggment.Await_time;
            fields[6] = aggment.Breakdown_time;
            fields[7] = aggment.Breakdown_rate;
            fields[8] = aggment.Start_date;
            fields[9] = aggment.End_date;
            string line = Common.GetLine(fields);
            string file = "RATEDATE" + "_" + DateTime.Now.ToString(Common.dtFmt2);
            string ext = ".csv";
            string fullname = Path + file + ext;
            using (StreamWriter sw = new StreamWriter(fullname, true, Common.eCust))
            {
                if (Common.fieldTitle)
                {
                    string[] titles = new string[10];
                    titles[0] = "ID";
                    titles[1] = "EQUIP_NO";
                    titles[2] = "SHIFT";
                    titles[3] = "RUNNING_TIME";
                    titles[4] = "ACT_RUNNING_TIME";
                    titles[5] = "AWAIT_TIME";
                    titles[6] = "BREAKDOWN_TIME";
                    titles[7] = "BREAKDOWN_RATE";
                    titles[8] = "START_DATE";
                    titles[9] = "END_DATE";
                    string titleline = Common.GetLine(titles);
                    sw.WriteLine(titleline);
                }
                sw.WriteLine(line);
            }
            var r = new FileInfo(fullname);
            File.Move(r.FullName, alarmPath + r.Name);
            timeIni.WriteString("Fault", "fault", "0");
            timeIni.WriteString("Fault", "actrun", "0");
            IniShift.CompareIniShift(ref Tshift, IniShift.OewiniShift(oewIni), timeIni);
            faultStopwatch.Reset();
            if (bofau)
                faultStopwatch.Start();
            actrunStopwatch.Reset();
            if (boact)
                actrunStopwatch.Start();
        }

        /// <summary>
        /// 创建稼动率表类
        /// </summary>
        /// <returns></returns>
        private Aggrandizement CreateAggrandizement()
        {
            Aggrandizement aggrandizement = new Aggrandizement()
            {
                Id = (Tshift.shift == 0)? "0":"1",
                Equip_no = System.Environment.MachineName,
                Shift = (Tshift.shift == 0) ? "0" : "1",
                Running_time = Runningtime.ToString(),
                Act_Running_time = Evaluation("Act_Running_time").ToString(),
                Await_time = Evaluation("Await_time").ToString(),
                Breakdown_time = Evaluation("Breakdown_time").ToString(),
                Breakdown_rate = Evaluation("Breakdown_rate").ToString(),
                Start_date = Tshift.starttime.ToShortTimeString(),
                End_date = Tshift.endtime.ToShortTimeString()
            };
            return aggrandizement;
        }

        /// <summary>
        /// 用算法求目标值
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        private double Evaluation(string s="")
        {
            double Breakdown_time = (Convert.ToDouble(timeIni.ReadString("Fault", "fault", "0")) + faultStopwatch.Elapsed.TotalSeconds) /60;
            double Await_time = (Convert.ToDouble(timeIni.ReadString("Fault", "actrun", "0")) + actrunStopwatch.Elapsed.TotalSeconds) / 60;
            double Act_Running_time = Runningtime - Await_time - Breakdown_time;
            double Breakdown_rate = Breakdown_time / Runningtime;
            switch (s)
            {
                case "Act_Running_time":
                    return Act_Running_time;
                case "Await_time":
                    return Await_time;
                case "Breakdown_time":
                    return Breakdown_time;
                case "Breakdown_rate":
                    return Breakdown_rate;
                default:
                    return 0;
            }
        }
        #endregion
    }
    #endregion

    #region 惠州胜宏科技通用类(对象)
    /// <summary>
    /// 稼动率表
    /// </summary>
    public class Aggrandizement
    {
        /// <summary>
        /// 唯一ID
        /// </summary>
        public string Id;
        /// <summary>
        /// 设备号
        /// </summary>
        public string Equip_no;
        /// <summary>
        /// 班次(0白班，1晚班)
        /// </summary>
        public string Shift;
        /// <summary>
        /// 理论运行时间(分)
        /// </summary>
        public string Running_time;
        /// <summary>
        /// 实际运行时间(分)
        /// </summary>
        public string Act_Running_time;
        /// <summary>
        /// 待机时间(分)
        /// </summary>
        public string Await_time;
        /// <summary>
        /// 故障停机时间(分)
        /// </summary>
        public string Breakdown_time;
        /// <summary>
        /// 稼动率
        /// </summary>
        public string Breakdown_rate;
        /// <summary>
        /// 开始时间
        /// </summary>
        public string Start_date;
        /// <summary>
        /// 结束时间
        /// </summary>
        public string End_date;
    }

    /// <summary>
    /// 类IniShift，描述一天的白班，晚班
    /// </summary>
    public class IniShift
    {
        /// <summary>
        /// 运行日期
        /// </summary>
        public DateTime date { get; set; }
        /// <summary>
        /// 班次(0白班，1晚班)
        /// </summary>
        public int shift { get; set; }
        /// <summary>
        /// 早班时间
        /// </summary>
        public DateTime starttime { get; set; }
        /// <summary>
        /// 晚班时间
        /// </summary>
        public DateTime endtime { get; set; }
        /// <summary>
        /// 故障停机时间(秒)
        /// </summary>
        public double fault { get; set; }
        /// <summary>
        /// 实际运行时间(秒)
        /// </summary>
        public double actrun { get; set; }
        /// <summary>
        /// 根据time.ini推理出公共类Tshift
        /// </summary>
        /// <param name="iniFiles"></param>
        /// <returns></returns>
        public static IniShift TimeiniShift(IniFiles iniFiles)
        {
            IniShift Tshift = new IniShift()
            {
                date = iniFiles.ReadDateTime("Fault", "date", string.Empty),
                shift = iniFiles.ReadInteger("Fault", "shift", 0),
                starttime = iniFiles.ReadDateTime("Fault", "daystart", string.Empty),
                endtime = iniFiles.ReadDateTime("Fault", "dayshift", string.Empty),
                fault = iniFiles.ReadFloat("Fault", "fault", 0),
                actrun = iniFiles.ReadFloat("Fault", "actrun", 0)
            };
            return Tshift;
        }
        /// <summary>
        /// 根据oew.ini和现在时间推理出IniShift
        /// </summary>
        /// <param name="iniFiles"></param>
        /// <returns></returns>
        public static IniShift OewiniShift(IniFiles iniFiles)
        {
            IniShift Oshift = new IniShift();
            string s1 = iniFiles.ReadString("General", "DayStart", string.Empty);
            string s2 = iniFiles.ReadString("General", "DayShift", string.Empty);
            Oshift = new IniShift()
            {
                date = iniFiles.ReadDateTime("General", "DayStart", string.Empty).Date,
                shift = 0,
                starttime = iniFiles.ReadDateTime("General", "DayStart", string.Empty),
                endtime = iniFiles.ReadDateTime("General", "DayShift", string.Empty),
                fault = 0,
                actrun = 0
            };
            //DateTime t1 = Convert.ToDateTime(s1);
            //DateTime t2 = Convert.ToDateTime(s2);
            //DateTime t3 = Convert.ToDateTime(DateTime.Now.ToShortTimeString());
            if (DateTime.Now >= Oshift.starttime && DateTime.Now < Oshift.endtime)
            {
            }
            else if (DateTime.Now > Oshift.endtime && DateTime.Now < Oshift.starttime.AddDays(1))
            {
                DateTime time = Oshift.starttime.AddDays(1);
                Oshift.starttime = Oshift.endtime;
                Oshift.endtime = time;
                if (DateTime.Now >= Oshift.starttime && DateTime.Now < Oshift.endtime)
                {
                    Oshift.shift = 1;
                }
                else
                {
                    Oshift.shift = 2;
                }
            }
            else
            {
                if (Convert.ToDateTime(DateTime.Now.ToShortTimeString()) < Convert.ToDateTime(s1))
                {
                    DateTime time = Oshift.endtime.AddDays(-1);
                    Oshift.endtime = Oshift.starttime;
                    Oshift.starttime = time;
                    Oshift.date = Oshift.date.AddDays(-1);
                    Oshift.shift = 2;
                }
            }
            return Oshift;
        }
        /// <summary>
        /// 公共类Tshift和另一个IniShift做比较
        /// </summary>
        /// <param name="iniShift1"></param>
        /// <param name="iniShift2"></param>
        /// <param name="iniFiles"></param>
        /// <returns></returns>
        public static bool CompareIniShift(ref IniShift iniShift1, IniShift iniShift2 , IniFiles iniFiles)
        {
            if (String.IsNullOrEmpty(iniShift1.date.ToString()) || String.IsNullOrEmpty(iniShift1.starttime.ToString()) || String.IsNullOrEmpty(iniShift1.endtime.ToString()))
            {
                iniFiles.WriteDateTime("Fault", "date", iniShift2.date.Date);
                iniFiles.WriteInteger("Fault", "shift", iniShift2.shift);
                iniFiles.WriteString("Fault", "daystart", iniShift2.starttime.ToShortTimeString());
                iniFiles.WriteString("Fault", "dayshift", iniShift2.endtime.ToShortTimeString());
                iniFiles.WriteString("Fault", "fault", iniShift2.fault.ToString());
                iniFiles.WriteString("Fault", "actrun", iniShift2.actrun.ToString());
                iniShift1 = iniShift2;
                return false;
            }
            if (iniShift1.date == iniShift2.date)
            {
                if (iniShift1.starttime == iniShift2.starttime && iniShift1.endtime == iniShift2.endtime)
                {
                    if (iniShift1.shift != iniShift2.shift)
                    {
                        iniShift1.shift = iniShift2.shift;
                        iniFiles.WriteInteger("Fault", "shift", iniShift2.shift);
                    }
                    else
                        return true;
                }
                else
                {
                    iniFiles.WriteInteger("Fault", "shift", iniShift2.shift);
                    iniFiles.WriteString("Fault", "daystart", iniShift2.starttime.ToShortTimeString());
                    iniFiles.WriteString("Fault", "dayshift", iniShift2.endtime.ToShortTimeString());
                    iniFiles.WriteString("Fault", "fault", iniShift2.fault.ToString());
                    iniFiles.WriteString("Fault", "actrun", iniShift2.actrun.ToString());
                    iniShift1.starttime = iniShift2.starttime;
                    iniShift1.endtime = iniShift2.endtime;
                    iniShift1.shift = iniShift2.shift;
                    iniShift1.fault = iniShift2.fault;
                    iniShift1.actrun = iniShift2.actrun;
                }
            }
            else
            {
                iniFiles.WriteDateTime("Fault", "date", iniShift2.date.Date);
                iniFiles.WriteInteger("Fault", "shift", iniShift2.shift);
                iniFiles.WriteString("Fault", "daystart", iniShift2.starttime.ToShortTimeString());
                iniFiles.WriteString("Fault", "dayshift", iniShift2.endtime.ToShortTimeString());
                iniFiles.WriteString("Fault", "fault", iniShift2.fault.ToString());
                iniFiles.WriteString("Fault", "actrun", iniShift2.actrun.ToString());
                iniShift1 = iniShift2;
                return false;
            }
            return true;
        }
    }

    /// <summary>
    /// 类Txtclass，描述D:\Output\*.txt里面的内容
    /// </summary>
    public class Txtclass
    {
        public Txtclass(){}

        /// <summary>
        /// VRS
        /// </summary>
        public string VRS_NO { get; set; }
        /// <summary>
        /// AOI
        /// </summary>
        public string AOI_NO { get; set; }
        /// <summary>
        /// 流程卡号
        /// </summary>
        public string FLOW_NO { get; set; }
        /// <summary>
        /// 料号
        /// </summary>
        public string PART_NO { get; set; }
        /// <summary>
        /// 批号
        /// </summary>
        public string LOT_NO { get; set; }
        /// <summary>
        /// 板号
        /// </summary>
        public string PNL_NO { get; set; }
        /// <summary>
        /// 序号
        /// </summary>
        public string Xuhao_NO { get; set; }
        /// <summary>
        /// 层别
        /// </summary>
        public string Layers { get; set; }
        /// <summary>
        /// SET数
        /// </summary>
        public string Set { get; set; }
        /// <summary>
        /// 良品SET数
        /// </summary>
        public string G_Set { get; set; }
        /// <summary>
        /// 不良品SET数
        /// </summary>
        public string F_Set { get; set; }
        /// <summary>
        /// PCS数
        /// </summary>
        public string Pcs { get; set; }
        /// <summary>
        /// 良品PCS数
        /// </summary>
        public string G_Pcs { get; set; }
        /// <summary>
        /// 不良品PCS数
        /// </summary>
        public string F_Pcs { get; set; }
        /// <summary>
        /// 操作开始时间
        /// </summary>
        public string START_DATE { get; set; }
        /// <summary>
        /// 操作结束时间
        /// </summary>
        public string END_DATE { get; set; }
        /// <summary>
        /// 记录时间
        /// </summary>
        public string RECORD_DATE { get; set; }
        /// <summary>
        /// 用户
        /// </summary>
        public string USER { get; set; }
    }

    /// <summary>
    /// 类SharePath，描述共享目录
    /// </summary>
    public class SharePath
    {
        /// <summary>
        /// 共享Data目录
        /// </summary>
        public string Data { get; set; }
        /// <summary>
        /// 共享Signal目录
        /// </summary>
        public string Signal { get; set; }
        /// <summary>
        /// 密码
        /// </summary>
        public string Password { get; set; }
        /// <summary>
        /// 用户名
        /// </summary>
        public string User { get; set; }
        /// <summary>
        /// 链接是否正常
        /// </summary>
        public bool data_Linking { get; set; } = false;
        /// <summary>
        /// 链接是否正常
        /// </summary>
        public bool signal_Linking { get; set; } = false;
        public SharePath(){}

        public SharePath(string data, string signal, string password, string user)
        {
            Data = data;
            Signal = signal;
            Password = password;
            User = user;
        }

        private static int lotExpiredDays { get; set; } = 31;

        /// <summary>
        /// 把文件保存到指定共享目录
        /// </summary>
        /// <param name="sharePath"></param>
        /// <param name="data_file">本地data目录</param>
        /// <param name="signal_file">本地data目录</param>
        public static void Save(SharePath sharePath, string data_file = "", string signal_file = "")
        {
            DateTime now = DateTime.Now;
            if (sharePath.data_Linking)
            {
                foreach (string ini in Directory.EnumerateFiles(data_file, "*.csv"))
                {
                    try
                    {
                        TimeSpan ts = now - Directory.GetLastWriteTime(ini);
                        if (ts.Days > lotExpiredDays)
                            File.Delete(ini);
                    }
                    catch (Exception ex) { }
                }
                if (sharePath.Data != null && !Convert.IsDBNull(sharePath.Data) && !string.IsNullOrEmpty(sharePath.Data.ToString()))
                {
                    foreach (var v in Directory.EnumerateFiles(data_file, "*.csv"))
                    {
                        UploadECCInvoice_Intranet(new FileInfo(v), sharePath.Data);
                        File.Delete(v);
                    }
                }
            }
            if (sharePath.signal_Linking)
            {
                foreach (string ini in Directory.EnumerateFiles(signal_file, "*.csv"))
                {
                    try
                    {
                        TimeSpan ts = now - Directory.GetLastWriteTime(ini);
                        if (ts.Days > lotExpiredDays)
                            File.Delete(ini);
                    }
                    catch (Exception ex) { }
                    if (sharePath.Signal != null && !Convert.IsDBNull(sharePath.Signal) && !string.IsNullOrEmpty(sharePath.Signal.ToString()))
                    {
                        foreach (var v in Directory.EnumerateFiles(signal_file, "*.csv"))
                        {
                            UploadECCInvoice_Intranet(new FileInfo(v), sharePath.Signal);
                            File.Delete(v);
                        }
                    }
                }

            }
        }

        /// <summary>  
        /// 从本地上传文件至服务器
        /// </summary>  
        /// <param name="src">远程服务器路径（共享文件夹路径）</param>  
        /// <param name="dst">本地文件夹路径</param>  
        /// <param name="fileName">上传至服务器上的文件名，包含扩展名</param>  
        private static void TransportRemoteToServer(string src, string dst, string fileName)
        {
            try
            {
                if (File.Exists(dst))
                {
                    src = src + fileName;
                    FileStream inFileStream = new FileStream(src, FileMode.OpenOrCreate);    //从远程服务器下载到本地的文件 
                    FileStream outFileStream = new FileStream(dst, FileMode.Open);    //远程服务器文件  此处假定远程服务器共享文件夹下确实包含本文件，否则程序报错  
                    byte[] buf = new byte[outFileStream.Length];
                    int byteCount;
                    while ((byteCount = outFileStream.Read(buf, 0, buf.Length)) > 0)
                        inFileStream.Write(buf, 0, byteCount);
                    inFileStream.Flush();
                    inFileStream.Close();
                    outFileStream.Flush();
                    outFileStream.Close();
                }
            }catch{}
        }

        /// <summary>  
        /// 连接远程共享文件夹  
        /// </summary>  
        /// <param name="path">远程共享文件夹的路径</param>  
        /// <param name="userName">用户名</param>  
        /// <param name="passWord">密码</param>  
        /// <returns></returns>
        public static void connectState(ref ShengHong sheng)
        {
            bool data_Flag = false;
            sheng.sharePath = new SharePath(ShengHong.timeIni.ReadString("Path", "Data", string.Empty), ShengHong.timeIni.ReadString("Path", "Signal", string.Empty), ShengHong.timeIni.ReadString("Path", "Password", string.Empty), ShengHong.timeIni.ReadString("Path", "User", string.Empty));
            Process data_proc = new Process();
            try
            {
                data_proc.StartInfo.FileName = "cmd.exe";
                data_proc.StartInfo.UseShellExecute = false;
                data_proc.StartInfo.RedirectStandardInput = true;
                data_proc.StartInfo.RedirectStandardOutput = true;
                data_proc.StartInfo.RedirectStandardError = true;
                data_proc.StartInfo.CreateNoWindow = true;
                data_proc.Start();
                data_proc.StandardInput.WriteLine("net use * /del /y");
                string dosLine = "net use " + sheng.sharePath.Data + " " + sheng.sharePath.Password + " /user:" + sheng.sharePath.User;
                data_proc.StandardInput.WriteLine(dosLine);
                data_proc.StandardInput.WriteLine("exit");
                while (!data_proc.HasExited)
                    data_proc.WaitForExit(1000);
                string errormsg = data_proc.StandardError.ReadToEnd();
                data_proc.StandardError.Close();
                if (string.IsNullOrEmpty(errormsg))
                    data_Flag = true;
                else {}
            }catch (Exception ex){}
            finally
            {
                data_proc.Close();
                data_proc.Dispose();
            }
            sheng.sharePath.data_Linking = data_Flag;
            bool signal_Flag = false;
            Process signal_proc = new Process();
            try
            {
                signal_proc.StartInfo.FileName = "cmd.exe";
                signal_proc.StartInfo.UseShellExecute = false;
                signal_proc.StartInfo.RedirectStandardInput = true;
                signal_proc.StartInfo.RedirectStandardOutput = true;
                signal_proc.StartInfo.RedirectStandardError = true;
                signal_proc.StartInfo.CreateNoWindow = true;
                signal_proc.Start();
                signal_proc.StandardInput.WriteLine("net use * /del /y");
                string dosLine = "net use " + sheng.sharePath.Signal + " " + sheng.sharePath.Password + " /user:" + sheng.sharePath.User;
                signal_proc.StandardInput.WriteLine(dosLine);
                signal_proc.StandardInput.WriteLine("exit");
                while (!signal_proc.HasExited)
                    signal_proc.WaitForExit(1000);
                string errormsg = signal_proc.StandardError.ReadToEnd();
                signal_proc.StandardError.Close();
                if (string.IsNullOrEmpty(errormsg))
                    signal_Flag = true;
                else { }
            }
            catch (Exception ex) { }
            finally
            {
                signal_proc.Close();
                signal_proc.Dispose();
            }
            sheng.sharePath.signal_Linking = signal_Flag;
            sheng.upwat = ShengHong.timeIni.ReadInteger("Path", "upwat", 10000);
        }

        /// <summary>
        /// 内网上传
        /// </summary>
        /// <param name="destinationFile">要上传的文件</param>
        /// <param name="serverFolder">内网目录路径</param>
        /// <param name="PWD">密码</param>
        /// <param name="Admini">用户名</param>
        private static void UploadECCInvoice_Intranet(FileInfo outpath, string path)
        {
            try 
            {
                //共享文件夹的目录  
                DirectoryInfo theFolder = new DirectoryInfo(path);
                string filename = theFolder.ToString();
                //执行方法   
                TransportRemoteToServer(path + @"\", outpath.FullName, outpath.Name);    //实现将远程服务器文件写入到本地
            }
            catch{}
        }
    }
    #endregion
}
